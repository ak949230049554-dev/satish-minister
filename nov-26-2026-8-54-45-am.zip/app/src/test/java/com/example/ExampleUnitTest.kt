package com.example

import com.example.data.astronomy.AstronomicalEphemerisEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun ephemerisDistancesAreWithinPhysicalOrbitalBounds() {
        val telemetry = AstronomicalEphemerisEngine.computeLiveTelemetry(1_764_126_600_000L)
        assertTrue(
            "Sun distance out of bounds: ${telemetry.sunDistanceKm}",
            telemetry.sunDistanceKm in 147_000_000L..152_200_000L
        )
        assertTrue(
            "Moon distance out of bounds: ${telemetry.moonDistanceKm}",
            telemetry.moonDistanceKm in 356_000L..407_000L
        )
        assertTrue(telemetry.moonIlluminationPercent in 0..100)
        assertTrue(telemetry.earthOrbitalSpeedKms in 29.0..30.6)
    }

    @Test
    fun indianNumberFormattingWorksCorrectly() {
        assertEquals("3,84,400", AstronomicalEphemerisEngine.formatIndianNumber(384400L))
        assertEquals("14,95,97,871", AstronomicalEphemerisEngine.formatIndianNumber(149597871L))
    }
}
