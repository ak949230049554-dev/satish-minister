package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.local.CityPreferencesStore
import com.example.data.remote.OpenMeteoNetworkProvider
import com.example.data.repository.WeatherSpaceRepository
import com.example.ui.MainTab
import com.example.ui.SkySpaceViewModel
import com.example.ui.components.CosmicBackdrop
import com.example.ui.screens.CityMapScreen
import com.example.ui.screens.SpaceScreen
import com.example.ui.screens.WeatherScreen
import com.example.ui.theme.CosmicDeepBg
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.NabhDrishtiTheme
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarAmberContainer

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            NabhDrishtiTheme {
                NabhDrishtiApp()
            }
        }
    }
}

private data class NavDestination(
    val tab: MainTab,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

@Composable
fun NabhDrishtiApp() {
    val context = LocalContext.current.applicationContext
    val repository = remember(context) {
        WeatherSpaceRepository(
            geocodingApi = OpenMeteoNetworkProvider.geocodingApi,
            forecastApi = OpenMeteoNetworkProvider.forecastApi,
            cityStore = CityPreferencesStore(context)
        )
    }
    val viewModel: SkySpaceViewModel = viewModel(
        factory = SkySpaceViewModel.factory(repository)
    )
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    val destinations = remember {
        listOf(
            NavDestination(
                tab = MainTab.WEATHER,
                labelRes = R.string.nav_weather,
                selectedIcon = Icons.Rounded.WbSunny,
                unselectedIcon = Icons.Outlined.WbSunny,
                testTag = "nav_weather_tab"
            ),
            NavDestination(
                tab = MainTab.SPACE,
                labelRes = R.string.nav_space,
                selectedIcon = Icons.Rounded.Public,
                unselectedIcon = Icons.Outlined.Public,
                testTag = "nav_space_tab"
            ),
            NavDestination(
                tab = MainTab.MAP,
                labelRes = R.string.nav_map,
                selectedIcon = Icons.Rounded.Map,
                unselectedIcon = Icons.Outlined.Map,
                testTag = "nav_map_tab"
            )
        )
    }

    Box(modifier = Modifier.fillMaxSize()) {
        CosmicBackdrop()

        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useNavigationRail = maxWidth >= 600.dp

            Scaffold(
                containerColor = ComposeColor.Transparent,
                contentWindowInsets = WindowInsets.safeDrawing,
                bottomBar = {
                    if (!useNavigationRail) {
                        NavigationBar(
                            containerColor = CosmicSurface.copy(alpha = 0.96f),
                            tonalElevation = 4.dp
                        ) {
                            destinations.forEach { dest ->
                                val selected = state.activeTab == dest.tab
                                val label = stringResource(dest.labelRes)
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(dest.tab) },
                                    modifier = Modifier.testTag(dest.testTag),
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = SolarAmber,
                                        selectedTextColor = SolarAmber,
                                        indicatorColor = SolarAmberContainer,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    if (useNavigationRail) {
                        NavigationRail(
                            modifier = Modifier.fillMaxHeight(),
                            containerColor = CosmicDeepBg.copy(alpha = 0.92f)
                        ) {
                            destinations.forEach { dest ->
                                val selected = state.activeTab == dest.tab
                                val label = stringResource(dest.labelRes)
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { viewModel.selectTab(dest.tab) },
                                    modifier = Modifier.testTag(dest.testTag),
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) dest.selectedIcon else dest.unselectedIcon,
                                            contentDescription = label
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.labelMedium
                                        )
                                    },
                                    colors = NavigationRailItemDefaults.colors(
                                        selectedIconColor = SolarAmber,
                                        selectedTextColor = SolarAmber,
                                        indicatorColor = SolarAmberContainer,
                                        unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                        unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }

                    Crossfade(
                        targetState = state.activeTab,
                        animationSpec = tween(durationMillis = 220),
                        label = "main_tab_crossfade",
                        modifier = Modifier.weight(1f)
                    ) { tab ->
                        when (tab) {
                            MainTab.WEATHER -> WeatherScreen(
                                state = state,
                                onSearchQueryChange = viewModel::onSearchQueryChanged,
                                onSubmitSearch = viewModel::submitCitySearch,
                                onClearSearch = viewModel::clearSearch,
                                onSelectCity = viewModel::selectCity,
                                onRefreshWeather = viewModel::refreshWeather
                            )

                            MainTab.SPACE -> SpaceScreen(
                                telemetry = state.spaceTelemetry,
                                onNavigateBackToWeather = { viewModel.selectTab(MainTab.WEATHER) }
                            )

                            MainTab.MAP -> CityMapScreen(
                                city = state.selectedCity,
                                weatherState = state.weatherState,
                                onNavigateBackToWeather = { viewModel.selectTab(MainTab.WEATHER) }
                            )
                        }
                    }
                }
            }
        }
    }
}
