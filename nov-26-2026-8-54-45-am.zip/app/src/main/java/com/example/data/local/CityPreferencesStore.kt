package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.CityLocation
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.cityDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "nabh_drishti_city_prefs"
)

class CityPreferencesStore(private val context: Context) {

    private object Keys {
        val NAME = stringPreferencesKey("city_name")
        val REGION = stringPreferencesKey("city_region")
        val COUNTRY = stringPreferencesKey("city_country")
        val LAT = doublePreferencesKey("city_lat")
        val LON = doublePreferencesKey("city_lon")
        val TIMEZONE = stringPreferencesKey("city_tz")
    }

    val defaultCity = CityLocation(
        name = "नई दिल्ली",
        region = "दिल्ली",
        country = "भारत",
        latitude = 28.6139,
        longitude = 77.2090,
        timezone = "Asia/Kolkata"
    )

    val savedCityFlow: Flow<CityLocation> = context.cityDataStore.data.map { prefs ->
        val name = prefs[Keys.NAME] ?: return@map defaultCity
        val lat = prefs[Keys.LAT] ?: return@map defaultCity
        val lon = prefs[Keys.LON] ?: return@map defaultCity
        CityLocation(
            name = name,
            region = prefs[Keys.REGION] ?: "",
            country = prefs[Keys.COUNTRY] ?: "",
            latitude = lat,
            longitude = lon,
            timezone = prefs[Keys.TIMEZONE] ?: "auto"
        )
    }

    suspend fun saveCity(city: CityLocation) {
        context.cityDataStore.edit { prefs ->
            prefs[Keys.NAME] = city.name
            prefs[Keys.REGION] = city.region
            prefs[Keys.COUNTRY] = city.country
            prefs[Keys.LAT] = city.latitude
            prefs[Keys.LON] = city.longitude
            prefs[Keys.TIMEZONE] = city.timezone
        }
    }
}
