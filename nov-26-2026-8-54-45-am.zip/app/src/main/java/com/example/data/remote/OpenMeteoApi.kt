package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@JsonClass(generateAdapter = true)
data class GeocodingResponseDto(
    @param:Json(name = "results") val results: List<GeocodingResultDto>? = null
)

@JsonClass(generateAdapter = true)
data class GeocodingResultDto(
    @param:Json(name = "name") val name: String,
    @param:Json(name = "latitude") val latitude: Double,
    @param:Json(name = "longitude") val longitude: Double,
    @param:Json(name = "country") val country: String? = null,
    @param:Json(name = "admin1") val admin1: String? = null,
    @param:Json(name = "timezone") val timezone: String? = null
)

@JsonClass(generateAdapter = true)
data class ForecastResponseDto(
    @param:Json(name = "timezone") val timezone: String? = null,
    @param:Json(name = "current") val current: CurrentWeatherDto? = null,
    @param:Json(name = "hourly") val hourly: HourlyWeatherDto? = null,
    @param:Json(name = "daily") val daily: DailyWeatherDto? = null
)

@JsonClass(generateAdapter = true)
data class CurrentWeatherDto(
    @param:Json(name = "time") val time: String? = null,
    @param:Json(name = "temperature_2m") val temperature2m: Double? = null,
    @param:Json(name = "relative_humidity_2m") val relativeHumidity2m: Int? = null,
    @param:Json(name = "apparent_temperature") val apparentTemperature: Double? = null,
    @param:Json(name = "is_day") val isDay: Int? = null,
    @param:Json(name = "weather_code") val weatherCode: Int? = null,
    @param:Json(name = "cloud_cover") val cloudCover: Int? = null,
    @param:Json(name = "wind_speed_10m") val windSpeed10m: Double? = null,
    @param:Json(name = "wind_direction_10m") val windDirection10m: Int? = null
)

@JsonClass(generateAdapter = true)
data class HourlyWeatherDto(
    @param:Json(name = "time") val time: List<String>? = null,
    @param:Json(name = "temperature_2m") val temperature2m: List<Double?>? = null,
    @param:Json(name = "precipitation_probability") val precipitationProbability: List<Int?>? = null,
    @param:Json(name = "precipitation") val precipitation: List<Double?>? = null,
    @param:Json(name = "weather_code") val weatherCode: List<Int?>? = null,
    @param:Json(name = "wind_speed_10m") val windSpeed10m: List<Double?>? = null,
    @param:Json(name = "is_day") val isDay: List<Int?>? = null
)

@JsonClass(generateAdapter = true)
data class DailyWeatherDto(
    @param:Json(name = "sunrise") val sunrise: List<String>? = null,
    @param:Json(name = "sunset") val sunset: List<String>? = null,
    @param:Json(name = "temperature_2m_max") val temperature2mMax: List<Double?>? = null,
    @param:Json(name = "temperature_2m_min") val temperature2mMin: List<Double?>? = null
)

interface OpenMeteoGeocodingApi {
    @GET("v1/search")
    suspend fun searchCities(
        @Query("name") query: String,
        @Query("count") count: Int = 8,
        @Query("language") language: String = "hi",
        @Query("format") format: String = "json"
    ): GeocodingResponseDto
}

interface OpenMeteoForecastApi {
    @GET("v1/forecast")
    suspend fun getForecast(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String =
            "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m",
        @Query("hourly") hourly: String =
            "temperature_2m,precipitation_probability,precipitation,weather_code,wind_speed_10m,is_day",
        @Query("daily") daily: String =
            "weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset",
        @Query("timezone") timezone: String = "auto",
        @Query("forecast_days") forecastDays: Int = 2
    ): ForecastResponseDto
}

object OpenMeteoNetworkProvider {
    private val okHttpClient: OkHttpClient by lazy {
        val logger = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BASIC
        }
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .addInterceptor(logger)
            .build()
    }

    val geocodingApi: OpenMeteoGeocodingApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://geocoding-api.open-meteo.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(OpenMeteoGeocodingApi::class.java)
    }

    val forecastApi: OpenMeteoForecastApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.open-meteo.com/")
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()
            .create(OpenMeteoForecastApi::class.java)
    }
}
