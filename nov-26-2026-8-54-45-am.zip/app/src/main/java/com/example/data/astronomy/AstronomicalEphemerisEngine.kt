package com.example.data.astronomy

import com.example.data.model.SpaceTelemetry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Computes real-time Earth-to-Sun and Earth-to-Moon orbital distances (km)
 * and lunar phase metrics using Jean Meeus astronomical algorithms.
 */
object AstronomicalEphemerisEngine {

    private const val AU_IN_KM = 149_597_870.7
    private const val SPEED_OF_LIGHT_KM_S = 299_792.458
    private const val SYNODIC_MONTH_DAYS = 29.530588853

    fun computeLiveTelemetry(epochMillis: Long = System.currentTimeMillis()): SpaceTelemetry {
        val jd = epochMillis / 86_400_000.0 + 2_440_587.5
        val t = (jd - 2_451_545.0) / 36_525.0

        // --- Solar Orbital Distance (Meeus Ch. 25) ---
        val sunMeanAnomalyDeg = normalizeDegrees(
            357.5291092 + 35_999.0502909 * t - 0.0001536 * t * t + t * t * t / 24_490_000.0
        )
        val sunMeanAnomalyRad = Math.toRadians(sunMeanAnomalyDeg)
        val earthEccentricity = 0.016708634 - 0.000042037 * t - 0.0000001267 * t * t

        val sunEquationCenterDeg =
            (1.914602 - 0.004817 * t - 0.000014 * t * t) * sin(sunMeanAnomalyRad) +
                (0.019993 - 0.000101 * t) * sin(2.0 * sunMeanAnomalyRad) +
                0.000289 * sin(3.0 * sunMeanAnomalyRad)

        val sunTrueAnomalyRad = Math.toRadians(sunMeanAnomalyDeg + sunEquationCenterDeg)
        val sunRadiusAu =
            (1.000001018 * (1.0 - earthEccentricity * earthEccentricity)) /
                (1.0 + earthEccentricity * cos(sunTrueAnomalyRad))

        val sunDistanceKm = (sunRadiusAu * AU_IN_KM).roundToLong()
        val sunDistanceCroreKm = sunDistanceKm / 10_000_000.0

        // Vis-viva equation for Earth's instantaneous orbital speed (km/s)
        // mu_sun = 1.3271244e11 km^3/s^2, a = AU_IN_KM
        val muSun = 1.3271244e11
        val earthSpeedKms = sqrt(muSun * (2.0 / sunDistanceKm - 1.0 / AU_IN_KM))

        val sunGeometricMeanLongDeg = normalizeDegrees(
            280.46646 + 36_000.76983 * t + 0.0003032 * t * t
        )
        val sunTrueLongitudeDeg = normalizeDegrees(sunGeometricMeanLongDeg + sunEquationCenterDeg)

        // --- Lunar Orbital Distance & Phase (Meeus Ch. 47) ---
        val lPrimeDeg = normalizeDegrees(
            218.3164477 + 481_267.88123421 * t - 0.0015786 * t * t + t * t * t / 538_841.0
        )
        val dDeg = normalizeDegrees(
            297.8501921 + 445_267.1114034 * t - 0.0018819 * t * t + t * t * t / 545_868.0
        )
        val mDeg = sunMeanAnomalyDeg
        val mPrimeDeg = normalizeDegrees(
            134.9633964 + 477_198.8675055 * t + 0.0087414 * t * t + t * t * t / 69_699.0
        )
        val fDeg = normalizeDegrees(
            93.2720950 + 483_202.0175233 * t - 0.0036539 * t * t - t * t * t / 3_526_000.0
        )

        val d = Math.toRadians(dDeg)
        val m = Math.toRadians(mDeg)
        val mPrime = Math.toRadians(mPrimeDeg)
        val f = Math.toRadians(fDeg)
        val eFactor = 1.0 - 0.002516 * t - 0.0000074 * t * t

        val sumR =
            -20_905_355.0 * cos(mPrime) -
                3_699_111.0 * cos(2.0 * d - mPrime) -
                2_955_968.0 * cos(2.0 * d) -
                569_925.0 * cos(2.0 * mPrime) +
                48_888.0 * eFactor * cos(m) -
                3_149.0 * cos(2.0 * f) +
                246_158.0 * cos(2.0 * d - 2.0 * mPrime) -
                152_138.0 * eFactor * cos(2.0 * d - m - mPrime) -
                170_733.0 * cos(2.0 * d + mPrime) -
                204_586.0 * eFactor * cos(2.0 * d - m) -
                129_620.0 * eFactor * cos(m - mPrime) +
                108_743.0 * cos(d) +
                104_755.0 * eFactor * cos(m + mPrime)

        val moonDistanceKm = (385_000.56 + sumR / 1000.0).roundToLong()

        // Moon phase angle & illumination (Meeus Ch. 48)
        val phaseAngleDeg = 180.0 - dDeg -
            6.289 * sin(mPrime) +
            2.100 * sin(m) -
            1.274 * sin(2.0 * d - mPrime) -
            0.658 * sin(2.0 * d) -
            0.214 * sin(2.0 * mPrime) -
            0.110 * sin(d)

        val illuminationFraction = (1.0 + cos(Math.toRadians(phaseAngleDeg))) / 2.0
        val moonIlluminationPercent = (illuminationFraction * 100.0).roundToInt().coerceIn(0, 100)

        val moonAgeDays = (normalizeDegrees(dDeg) / 360.0) * SYNODIC_MONTH_DAYS
        val moonPhaseHindi = resolveHindiMoonPhase(normalizeDegrees(dDeg))

        // Light travel times
        val sunLightSeconds = (sunDistanceKm / SPEED_OF_LIGHT_KM_S).roundToInt()
        val sunMinutes = sunLightSeconds / 60
        val sunSeconds = sunLightSeconds % 60
        val sunLightTravelHindi = "$sunMinutes मिनट $sunSeconds सेकंड"

        val moonLightSeconds = moonDistanceKm / SPEED_OF_LIGHT_KM_S
        val moonLightTravelHindi = String.format(Locale("hi", "IN"), "%.2f सेकंड", moonLightSeconds)

        val timeFormatter = SimpleDateFormat("hh:mm:ss a", Locale("hi", "IN"))
        val liveTimestampHindi = timeFormatter.format(Date(epochMillis))

        return SpaceTelemetry(
            sunDistanceKm = sunDistanceKm,
            sunDistanceCroreKm = sunDistanceCroreKm,
            moonDistanceKm = moonDistanceKm,
            sunLightTravelHindi = sunLightTravelHindi,
            moonLightTravelHindi = moonLightTravelHindi,
            moonIlluminationPercent = moonIlluminationPercent,
            moonPhaseHindi = moonPhaseHindi,
            moonAgeDays = moonAgeDays,
            earthOrbitalSpeedKms = earthSpeedKms,
            sunOrbitAngleDeg = sunTrueLongitudeDeg,
            moonOrbitAngleDeg = normalizeDegrees(lPrimeDeg),
            liveTimestampHindi = liveTimestampHindi
        )
    }

    private fun resolveHindiMoonPhase(elongationDeg: Double): String = when {
        elongationDeg < 15.0 || elongationDeg >= 345.0 -> "अमावस्या (नया चांद)"
        elongationDeg < 75.0 -> "शुक्ल पक्ष — बाल चंद्र"
        elongationDeg < 105.0 -> "शुक्ल अष्टमी (अर्ध चंद्र)"
        elongationDeg < 165.0 -> "शुक्ल पक्ष — बढ़ता चांद"
        elongationDeg < 195.0 -> "पूर्णिमा (पूर्ण चंद्र)"
        elongationDeg < 255.0 -> "कृष्ण पक्ष — घटता चांद"
        elongationDeg < 285.0 -> "कृष्ण अष्टमी (अर्ध चंद्र)"
        else -> "कृष्ण पक्ष — क्षीण चंद्र"
    }

    private fun normalizeDegrees(deg: Double): Double {
        val modded = deg % 360.0
        return if (modded < 0.0) modded + 360.0 else modded
    }

    fun formatIndianNumber(value: Long): String {
        val digits = value.toString()
        if (digits.length <= 3) return digits
        val lastThree = digits.takeLast(3)
        val remaining = digits.dropLast(3)
        val grouped = remaining.reversed().chunked(2).joinToString(",").reversed()
        return "$grouped,$lastThree"
    }
}
