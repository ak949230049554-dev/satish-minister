package com.example.data.model

data class CityLocation(
    val name: String,
    val region: String,
    val country: String,
    val latitude: Double,
    val longitude: Double,
    val timezone: String = "auto"
) {
    val displayName: String
        get() = listOf(name, region, country)
            .filter { it.isNotBlank() }
            .distinct()
            .joinToString(", ")
}

data class HourlyForecastItem(
    val isoTime: String,
    val hourLabel: String,
    val temperatureC: Double,
    val rainProbabilityPercent: Int,
    val precipitationMm: Double,
    val windSpeedKmh: Double,
    val weatherCode: Int,
    val isDay: Boolean
)

data class WeatherReport(
    val city: CityLocation,
    val currentTempC: Double,
    val feelsLikeTempC: Double,
    val windSpeedKmh: Double,
    val windDirectionDeg: Int,
    val windDirectionHindi: String,
    val humidityPercent: Int,
    val cloudCoverPercent: Int,
    val weatherCode: Int,
    val isDay: Boolean,
    val sunriseTime: String,
    val sunsetTime: String,
    val maxTempC: Double,
    val minTempC: Double,
    val weatherSummaryHindi: String,
    val thermalComfortHindi: String,
    val isWarmThermal: Boolean,
    val rainForecastTitleHindi: String,
    val rainForecastDetailHindi: String,
    val hasUpcomingRain: Boolean,
    val nextRainProbabilityPercent: Int,
    val sunForecastTitleHindi: String,
    val sunForecastDetailHindi: String,
    val hourlyForecast: List<HourlyForecastItem>,
    val updatedAtLabel: String
)

data class SpaceTelemetry(
    val sunDistanceKm: Long,
    val sunDistanceCroreKm: Double,
    val moonDistanceKm: Long,
    val sunLightTravelHindi: String,
    val moonLightTravelHindi: String,
    val moonIlluminationPercent: Int,
    val moonPhaseHindi: String,
    val moonAgeDays: Double,
    val earthOrbitalSpeedKms: Double,
    val sunOrbitAngleDeg: Double,
    val moonOrbitAngleDeg: Double,
    val liveTimestampHindi: String
)

sealed interface WeatherUiState {
    data object Loading : WeatherUiState
    data class Success(val report: WeatherReport) : WeatherUiState
    data class Error(val messageHindi: String) : WeatherUiState
}
