package com.example.data.repository

import com.example.data.local.CityPreferencesStore
import com.example.data.model.CityLocation
import com.example.data.model.HourlyForecastItem
import com.example.data.model.WeatherReport
import com.example.data.remote.OpenMeteoForecastApi
import com.example.data.remote.OpenMeteoGeocodingApi
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class WeatherSpaceRepository(
    private val geocodingApi: OpenMeteoGeocodingApi,
    private val forecastApi: OpenMeteoForecastApi,
    private val cityStore: CityPreferencesStore
) {

    val savedCityFlow: Flow<CityLocation> = cityStore.savedCityFlow

    val popularCities: List<CityLocation> = listOf(
        CityLocation("नई दिल्ली", "दिल्ली", "भारत", 28.6139, 77.2090, "Asia/Kolkata"),
        CityLocation("मुंबई", "महाराष्ट्र", "भारत", 19.0760, 72.8777, "Asia/Kolkata"),
        CityLocation("जयपुर", "राजस्थान", "भारत", 26.9124, 75.7873, "Asia/Kolkata"),
        CityLocation("बेंगलुरु", "कर्नाटक", "भारत", 12.9716, 77.5946, "Asia/Kolkata"),
        CityLocation("वाराणसी", "उत्तर प्रदेश", "भारत", 25.3176, 82.9739, "Asia/Kolkata"),
        CityLocation("कोलकाता", "पश्चिम बंगाल", "भारत", 22.5726, 88.3639, "Asia/Kolkata")
    )

    suspend fun saveSelectedCity(city: CityLocation) {
        cityStore.saveCity(city)
    }

    suspend fun searchCities(query: String): List<CityLocation> {
        val trimmed = query.trim()
        if (trimmed.length < 2) return emptyList()
        val response = geocodingApi.searchCities(query = trimmed)
        return response.results.orEmpty().map { dto ->
            CityLocation(
                name = dto.name,
                region = dto.admin1.orEmpty(),
                country = dto.country.orEmpty(),
                latitude = dto.latitude,
                longitude = dto.longitude,
                timezone = dto.timezone ?: "auto"
            )
        }
    }

    suspend fun fetchWeather(city: CityLocation): WeatherReport {
        val dto = forecastApi.getForecast(
            latitude = city.latitude,
            longitude = city.longitude
        )

        val current = dto.current ?: error("वर्तमान मौसम डेटा उपलब्ध नहीं है")
        val currentTimeIso = current.time.orEmpty()

        val hourlyTimes = dto.hourly?.time.orEmpty()
        val hourlyTemps = dto.hourly?.temperature2m.orEmpty()
        val hourlyRainProb = dto.hourly?.precipitationProbability.orEmpty()
        val hourlyPrecip = dto.hourly?.precipitation.orEmpty()
        val hourlyCodes = dto.hourly?.weatherCode.orEmpty()
        val hourlyWinds = dto.hourly?.windSpeed10m.orEmpty()
        val hourlyIsDay = dto.hourly?.isDay.orEmpty()

        val startIndex = hourlyTimes.indexOfFirst { it >= currentTimeIso }.let { idx ->
            if (idx >= 0) idx else 0
        }

        val next24Hours = (startIndex until minOf(startIndex + 24, hourlyTimes.size)).map { i ->
            val iso = hourlyTimes[i]
            HourlyForecastItem(
                isoTime = iso,
                hourLabel = formatHourToHindi(iso),
                temperatureC = hourlyTemps.getOrNull(i) ?: 0.0,
                rainProbabilityPercent = hourlyRainProb.getOrNull(i) ?: 0,
                precipitationMm = hourlyPrecip.getOrNull(i) ?: 0.0,
                windSpeedKmh = hourlyWinds.getOrNull(i) ?: 0.0,
                weatherCode = hourlyCodes.getOrNull(i) ?: 0,
                isDay = (hourlyIsDay.getOrNull(i) ?: 1) == 1
            )
        }

        val currentTemp = current.temperature2m ?: 0.0
        val feelsLike = current.apparentTemperature ?: currentTemp
        val windSpeed = current.windSpeed10m ?: 0.0
        val windDirDeg = current.windDirection10m ?: 0
        val humidity = current.relativeHumidity2m ?: 0
        val cloudCover = current.cloudCover ?: 0
        val weatherCode = current.weatherCode ?: 0
        val isDay = (current.isDay ?: 1) == 1

        val sunriseRaw = dto.daily?.sunrise?.firstOrNull().orEmpty()
        val sunsetRaw = dto.daily?.sunset?.firstOrNull().orEmpty()
        val sunriseLabel = formatHourToHindi(sunriseRaw, includeMinutes = true)
        val sunsetLabel = formatHourToHindi(sunsetRaw, includeMinutes = true)
        val maxTemp = dto.daily?.temperature2mMax?.firstOrNull() ?: currentTemp
        val minTemp = dto.daily?.temperature2mMin?.firstOrNull() ?: currentTemp

        val (thermalText, isWarm) = resolveThermalComfort(feelsLike)
        val (rainTitle, rainDetail, hasRain, nextRainProb) = buildRainForecastHindi(
            currentCode = weatherCode,
            hourly = next24Hours
        )
        val (sunTitle, sunDetail) = buildSunForecastHindi(
            isDay = isDay,
            cloudCover = cloudCover,
            sunriseLabel = sunriseLabel,
            sunsetLabel = sunsetLabel,
            hourly = next24Hours
        )

        val updatedFormatter = SimpleDateFormat("hh:mm a", Locale("hi", "IN"))

        return WeatherReport(
            city = city,
            currentTempC = currentTemp,
            feelsLikeTempC = feelsLike,
            windSpeedKmh = windSpeed,
            windDirectionDeg = windDirDeg,
            windDirectionHindi = windDirectionToHindi(windDirDeg),
            humidityPercent = humidity,
            cloudCoverPercent = cloudCover,
            weatherCode = weatherCode,
            isDay = isDay,
            sunriseTime = sunriseLabel,
            sunsetTime = sunsetLabel,
            maxTempC = maxTemp,
            minTempC = minTemp,
            weatherSummaryHindi = weatherCodeToHindi(weatherCode),
            thermalComfortHindi = thermalText,
            isWarmThermal = isWarm,
            rainForecastTitleHindi = rainTitle,
            rainForecastDetailHindi = rainDetail,
            hasUpcomingRain = hasRain,
            nextRainProbabilityPercent = nextRainProb,
            sunForecastTitleHindi = sunTitle,
            sunForecastDetailHindi = sunDetail,
            hourlyForecast = next24Hours,
            updatedAtLabel = updatedFormatter.format(Date())
        )
    }

    private data class RainSummary(
        val title: String,
        val detail: String,
        val hasRain: Boolean,
        val maxProb: Int
    )

    private fun buildRainForecastHindi(
        currentCode: Int,
        hourly: List<HourlyForecastItem>
    ): RainSummary {
        val isRainingNow = currentCode in listOf(51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82, 95, 96, 99)
        val peakHour = hourly.maxByOrNull { it.rainProbabilityPercent }
        val peakProb = peakHour?.rainProbabilityPercent ?: 0
        val nextRainHour = hourly.firstOrNull {
            it.rainProbabilityPercent >= 35 || it.precipitationMm >= 0.2 ||
                it.weatherCode in listOf(51, 53, 55, 61, 63, 65, 80, 81, 82, 95, 96, 99)
        }

        return when {
            isRainingNow -> RainSummary(
                title = "अभी बारिश हो रही है",
                detail = "अगले घंटों में ${peakProb}% तक वर्षा संभावना बनी हुई है।",
                hasRain = true,
                maxProb = maxOf(peakProb, 70)
            )
            nextRainHour != null -> RainSummary(
                title = "${nextRainHour.hourLabel} के आसपास बारिश संभावित",
                detail = "${nextRainHour.rainProbabilityPercent}% बारिश की संभावना (${String.format(Locale.US, "%.1f", nextRainHour.precipitationMm)} mm) दिख रही है।",
                hasRain = true,
                maxProb = peakProb
            )
            else -> RainSummary(
                title = "अगले 24 घंटे बारिश नहीं",
                detail = "अधिकतम वर्षा संभावना केवल ${peakProb}% है, मौसम शुष्क रहेगा।",
                hasRain = false,
                maxProb = peakProb
            )
        }
    }

    private fun buildSunForecastHindi(
        isDay: Boolean,
        cloudCover: Int,
        sunriseLabel: String,
        sunsetLabel: String,
        hourly: List<HourlyForecastItem>
    ): Pair<String, String> {
        val sunnyHour = hourly.firstOrNull {
            it.isDay && it.weatherCode in listOf(0, 1, 2) && it.rainProbabilityPercent < 30
        }
        return when {
            isDay && cloudCover <= 35 -> {
                "अभी तेज़ व साफ़ धूप खिली है" to
                    "सूर्योदय $sunriseLabel • सूर्यास्त $sunsetLabel (बादल केवल $cloudCover%)"
            }
            isDay && sunnyHour != null -> {
                "${sunnyHour.hourLabel} से धूप साफ़ होने के आसार" to
                    "सूर्यास्त $sunsetLabel बजे होगा; दिन में हल्के बादल ($cloudCover%) रहेंगे।"
            }
            !isDay && sunriseLabel.isNotBlank() -> {
                "कल सुबह $sunriseLabel बजे धूप निकलेगी" to
                    "अभी रात का समय है; कल सूर्यास्त $sunsetLabel बजे होगा।"
            }
            else -> {
                "हल्की धूप व बादलों की आवाजाही" to
                    "सूर्योदय $sunriseLabel • सूर्यास्त $sunsetLabel"
            }
        }
    }

    private fun resolveThermalComfort(feelsLikeC: Double): Pair<String, Boolean> = when {
        feelsLikeC < 10.0 -> "कड़ाके की ठंड" to false
        feelsLikeC < 18.0 -> "सुहावनी ठंड" to false
        feelsLikeC < 26.0 -> "सुखद और संतुलित मौसम" to false
        feelsLikeC < 33.0 -> "हल्की गर्मी" to true
        feelsLikeC < 40.0 -> "तेज़ गर्मी" to true
        else -> "भीषण लू और गर्मी" to true
    }

    private fun windDirectionToHindi(deg: Int): String {
        val normalized = ((deg % 360) + 360) % 360
        return when (((normalized + 22.5) / 45.0).toInt() % 8) {
            0 -> "उत्तर"
            1 -> "उत्तर-पूर्व"
            2 -> "पूर्व"
            3 -> "दक्षिण-पूर्व"
            4 -> "दक्षिण"
            5 -> "दक्षिण-पश्चिम"
            6 -> "पश्चिम"
            else -> "उत्तर-पश्चिम"
        }
    }

    private fun formatHourToHindi(iso: String, includeMinutes: Boolean = false): String {
        val timePart = iso.substringAfter("T", "")
        if (timePart.length < 5) return iso
        val hour24 = timePart.substring(0, 2).toIntOrNull() ?: return timePart
        val minute = timePart.substring(3, 5).toIntOrNull() ?: 0
        val period = when {
            hour24 < 4 -> "रात"
            hour24 < 12 -> "सुबह"
            hour24 < 16 -> "दोपहर"
            hour24 < 20 -> "शाम"
            else -> "रात"
        }
        val hour12 = when {
            hour24 == 0 -> 12
            hour24 > 12 -> hour24 - 12
            else -> hour24
        }
        return if (includeMinutes) {
            String.format(Locale.US, "%s %d:%02d", period, hour12, minute)
        } else {
            "$period $hour12 बजे"
        }
    }

    fun weatherCodeToHindi(code: Int): String = when (code) {
        0 -> "बिल्कुल साफ़ आसमान"
        1 -> "मुख्यतः साफ़ मौसम"
        2 -> "आंशिक बादल"
        3 -> "घने बादल छाए हैं"
        45, 48 -> "धुंध और कोहरा"
        51, 53, 55 -> "हल्की बूंदाबांदी"
        56, 57 -> "ठंडी फुहारें"
        61 -> "हल्की बारिश"
        63 -> "मध्यम बारिश"
        65 -> "मूसलाधार बारिश"
        66, 67 -> "बर्फीली बारिश"
        71, 73, 75, 77 -> "बर्फ़बारी"
        80, 81, 82 -> "तेज़ बौछारें"
        85, 86 -> "बर्फीली बौछारें"
        95 -> "गरज-चमक के साथ बारिश"
        96, 99 -> "ओलावृष्टि और तेज़ तूफ़ान"
        else -> "बदलता मौसम (${code.roundToInt()})"
    }
}

private fun Int.roundToInt(): Int = this
