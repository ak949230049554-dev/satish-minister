package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.shape.RoundedCornerShape

private val CosmicDarkColorScheme = darkColorScheme(
    primary = SolarAmber,
    onPrimary = SolarAmberDark,
    primaryContainer = SolarAmberContainer,
    onPrimaryContainer = TextIvory,
    secondary = LunarCyan,
    onSecondary = CosmicDeepBg,
    secondaryContainer = LunarCyanContainer,
    onSecondaryContainer = TextIvory,
    tertiary = RainIndigo,
    onTertiary = CosmicDeepBg,
    tertiaryContainer = RainIndigoContainer,
    onTertiaryContainer = TextIvory,
    background = CosmicDeepBg,
    onBackground = TextIvory,
    surface = CosmicSurface,
    onSurface = TextIvory,
    surfaceVariant = CosmicSurfaceElevated,
    onSurfaceVariant = TextSlate,
    outline = CosmicOutline,
    error = ErrorCoral,
    onError = CosmicDeepBg
)

val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp)
)

@Composable
fun NabhDrishtiTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CosmicDarkColorScheme,
        typography = AppTypography,
        shapes = AppShapes,
        content = content
    )
}
