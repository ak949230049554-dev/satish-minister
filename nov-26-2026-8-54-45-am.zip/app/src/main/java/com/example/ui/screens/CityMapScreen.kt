package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Map
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.BuildConfig
import com.example.R
import com.example.data.model.CityLocation
import com.example.data.model.WeatherUiState
import com.example.ui.theme.CosmicOutline
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SpaceGroteskFontFamily
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState
import java.util.Locale
import kotlin.math.roundToInt

@Composable
fun CityMapScreen(
    city: CityLocation,
    weatherState: WeatherUiState,
    onNavigateBackToWeather: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBackToWeather)

    val mapsKey = BuildConfig.MAPS_API_KEY
    val hasValidMapsKey = mapsKey.isNotBlank() && mapsKey != "YOUR_MAPS_API_KEY"

    Box(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MapCityHeaderCard(city = city, weatherState = weatherState)

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .testTag("city_map_container"),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                border = BorderStroke(1.dp, CosmicOutline)
            ) {
                if (hasValidMapsKey) {
                    LiveGoogleMapContent(
                        city = city,
                        weatherState = weatherState
                    )
                } else {
                    CoordinateRadarFallbackContent(
                        city = city,
                        weatherState = weatherState
                    )
                }
            }
        }
    }
}

@Composable
private fun MapCityHeaderCard(
    city: CityLocation,
    weatherState: WeatherUiState
) {
    val coords = String.format(
        Locale.US,
        "%.4f° N, %.4f° E",
        city.latitude,
        city.longitude
    )
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = CosmicSurfaceElevated),
        border = BorderStroke(1.dp, CosmicOutline)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Map,
                        contentDescription = stringResource(R.string.map_header_title),
                        tint = SolarAmber,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = city.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Text(
                    text = "${stringResource(R.string.map_coordinates)}: $coords",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontFamily = SpaceGroteskFontFamily
                    ),
                    color = LunarCyan
                )
            }

            if (weatherState is WeatherUiState.Success) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = CosmicSurface,
                    border = BorderStroke(1.dp, SolarAmber.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "${weatherState.report.currentTempC.roundToInt()}°C",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = SpaceGroteskFontFamily
                            ),
                            color = SolarAmber
                        )
                        Text(
                            text = "${weatherState.report.windSpeedKmh.roundToInt()} km/h",
                            style = MaterialTheme.typography.labelMedium,
                            color = LunarCyan
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LiveGoogleMapContent(
    city: CityLocation,
    weatherState: WeatherUiState
) {
    val targetLatLng = LatLng(city.latitude, city.longitude)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(targetLatLng, 10f)
    }
    var mapLoaded by remember { mutableStateOf(false) }

    LaunchedEffect(mapLoaded, city.latitude, city.longitude) {
        if (mapLoaded) {
            cameraPositionState.animate(
                CameraUpdateFactory.newLatLngZoom(targetLatLng, 10.5f)
            )
        }
    }

    val snippet = if (weatherState is WeatherUiState.Success) {
        "${weatherState.report.currentTempC.roundToInt()}°C • ${weatherState.report.weatherSummaryHindi}"
    } else {
        city.displayName
    }

    val markerState = remember(city.latitude, city.longitude) {
        MarkerState(position = targetLatLng)
    }

    GoogleMap(
        modifier = Modifier.fillMaxSize(),
        cameraPositionState = cameraPositionState,
        properties = MapProperties(mapType = MapType.NORMAL),
        uiSettings = MapUiSettings(
            zoomControlsEnabled = true,
            compassEnabled = true
        ),
        onMapLoaded = { mapLoaded = true }
    ) {
        Marker(
            state = markerState,
            title = city.name,
            snippet = snippet
        )
    }
}

@Composable
private fun CoordinateRadarFallbackContent(
    city: CityLocation,
    weatherState: WeatherUiState
) {
    Box(modifier = Modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height * 0.44f)
            val maxR = size.minDimension * 0.42f

            // Coordinate graticule lines
            val step = 56f
            var x = 0f
            while (x < size.width) {
                drawLine(
                    color = CosmicOutline.copy(alpha = 0.28f),
                    start = Offset(x, 0f),
                    end = Offset(x, size.height),
                    strokeWidth = 1f
                )
                x += step
            }
            var y = 0f
            while (y < size.height) {
                drawLine(
                    color = CosmicOutline.copy(alpha = 0.28f),
                    start = Offset(0f, y),
                    end = Offset(size.width, y),
                    strokeWidth = 1f
                )
                y += step
            }

            // Concentric radar rings
            listOf(0.33f, 0.66f, 1.0f).forEach { factor ->
                drawCircle(
                    color = LunarCyan.copy(alpha = 0.25f),
                    radius = maxR * factor,
                    center = center,
                    style = Stroke(width = 2f)
                )
            }

            // Glowing city beacon
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        SolarAmber.copy(alpha = 0.5f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = 64f
                ),
                center = center,
                radius = 64f
            )
            drawCircle(
                color = SolarAmber,
                radius = 12f,
                center = center
            )
        }

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = CosmicSurfaceElevated.copy(alpha = 0.92f),
                border = BorderStroke(1.dp, LunarCyan.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.LocationOn,
                        contentDescription = null,
                        tint = SolarAmber,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = city.displayName,
                        style = MaterialTheme.typography.labelLarge,
                        color = Color.White
                    )
                }
            }
        }

        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(18.dp),
            color = CosmicSurfaceElevated.copy(alpha = 0.94f),
            border = BorderStroke(1.dp, CosmicOutline)
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Surface(
                    shape = CircleShape,
                    color = SolarAmber.copy(alpha = 0.16f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Explore,
                        contentDescription = null,
                        tint = SolarAmber,
                        modifier = Modifier.padding(8.dp)
                    )
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = stringResource(R.string.map_key_notice_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = stringResource(R.string.map_key_notice_body),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (weatherState is WeatherUiState.Success) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "वर्तमान स्थिति: ${weatherState.report.weatherSummaryHindi} • हवा ${weatherState.report.windSpeedKmh.roundToInt()} km/h",
                            style = MaterialTheme.typography.labelLarge,
                            color = LunarCyan
                        )
                    }
                }
            }
        }
    }
}
