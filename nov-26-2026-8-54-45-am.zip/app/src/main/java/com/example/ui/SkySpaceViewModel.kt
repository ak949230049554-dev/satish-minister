package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.astronomy.AstronomicalEphemerisEngine
import com.example.data.model.CityLocation
import com.example.data.model.SpaceTelemetry
import com.example.data.model.WeatherUiState
import com.example.data.repository.WeatherSpaceRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class MainTab {
    WEATHER,
    SPACE,
    MAP
}

data class MainUiState(
    val activeTab: MainTab = MainTab.WEATHER,
    val selectedCity: CityLocation = CityLocation(
        name = "नई दिल्ली",
        region = "दिल्ली",
        country = "भारत",
        latitude = 28.6139,
        longitude = 77.2090,
        timezone = "Asia/Kolkata"
    ),
    val weatherState: WeatherUiState = WeatherUiState.Loading,
    val searchQuery: String = "",
    val searchResults: List<CityLocation> = emptyList(),
    val isSearching: Boolean = false,
    val searchMessageHindi: String? = null,
    val popularCities: List<CityLocation> = emptyList(),
    val spaceTelemetry: SpaceTelemetry = AstronomicalEphemerisEngine.computeLiveTelemetry()
)

class SkySpaceViewModel(
    private val repository: WeatherSpaceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        MainUiState(popularCities = repository.popularCities)
    )
    val uiState: StateFlow<MainUiState> = _uiState.asStateFlow()

    private var searchJob: Job? = null
    private var weatherJob: Job? = null

    init {
        startSpaceTelemetryTicker()
        loadInitialCityWeather()
    }

    private fun startSpaceTelemetryTicker() {
        viewModelScope.launch {
            while (isActive) {
                _uiState.update { state ->
                    state.copy(
                        spaceTelemetry = AstronomicalEphemerisEngine.computeLiveTelemetry()
                    )
                }
                delay(1000L)
            }
        }
    }

    private fun loadInitialCityWeather() {
        viewModelScope.launch {
            val savedCity = repository.savedCityFlow.first()
            _uiState.update { it.copy(selectedCity = savedCity) }
            loadWeatherForCity(savedCity)
        }
    }

    fun selectTab(tab: MainTab) {
        _uiState.update { it.copy(activeTab = tab) }
    }

    fun onSearchQueryChanged(query: String) {
        _uiState.update {
            it.copy(
                searchQuery = query,
                searchMessageHindi = null
            )
        }
        searchJob?.cancel()
        val trimmed = query.trim()
        if (trimmed.length < 2) {
            _uiState.update { it.copy(searchResults = emptyList(), isSearching = false) }
            return
        }
        searchJob = viewModelScope.launch {
            delay(350L)
            performCitySearch(trimmed)
        }
    }

    fun submitCitySearch() {
        val trimmed = _uiState.value.searchQuery.trim()
        if (trimmed.length < 2) {
            _uiState.update {
                it.copy(searchMessageHindi = "कृपया कम से कम 2 अक्षर लिखें")
            }
            return
        }
        searchJob?.cancel()
        searchJob = viewModelScope.launch {
            performCitySearch(trimmed)
        }
    }

    private suspend fun performCitySearch(query: String) {
        _uiState.update { it.copy(isSearching = true, searchMessageHindi = null) }
        try {
            val results = repository.searchCities(query)
            _uiState.update {
                it.copy(
                    searchResults = results,
                    isSearching = false,
                    searchMessageHindi = if (results.isEmpty()) {
                        "कोई शहर नहीं मिला — कृपया सही नाम लिखें"
                    } else {
                        null
                    }
                )
            }
        } catch (_: Exception) {
            _uiState.update {
                it.copy(
                    isSearching = false,
                    searchResults = emptyList(),
                    searchMessageHindi = "शहर खोजने में नेटवर्क त्रुटि हुई"
                )
            }
        }
    }

    fun clearSearch() {
        searchJob?.cancel()
        _uiState.update {
            it.copy(
                searchQuery = "",
                searchResults = emptyList(),
                isSearching = false,
                searchMessageHindi = null
            )
        }
    }

    fun selectCity(city: CityLocation) {
        searchJob?.cancel()
        _uiState.update {
            it.copy(
                selectedCity = city,
                searchQuery = "",
                searchResults = emptyList(),
                isSearching = false,
                searchMessageHindi = null
            )
        }
        viewModelScope.launch {
            repository.saveSelectedCity(city)
        }
        loadWeatherForCity(city)
    }

    fun refreshWeather() {
        loadWeatherForCity(_uiState.value.selectedCity)
    }

    private fun loadWeatherForCity(city: CityLocation) {
        weatherJob?.cancel()
        weatherJob = viewModelScope.launch {
            _uiState.update { it.copy(weatherState = WeatherUiState.Loading) }
            try {
                val report = repository.fetchWeather(city)
                _uiState.update { it.copy(weatherState = WeatherUiState.Success(report)) }
            } catch (_: Exception) {
                _uiState.update {
                    it.copy(
                        weatherState = WeatherUiState.Error(
                            "इंटरनेट कनेक्शन जांचें और पुनः प्रयास करें।"
                        )
                    )
                }
            }
        }
    }

    companion object {
        fun factory(repository: WeatherSpaceRepository): ViewModelProvider.Factory =
            object : ViewModelProvider.Factory {
                @Suppress("UNCHECKED_CAST")
                override fun <T : ViewModel> create(modelClass: Class<T>): T {
                    return SkySpaceViewModel(repository) as T
                }
            }
    }
}
