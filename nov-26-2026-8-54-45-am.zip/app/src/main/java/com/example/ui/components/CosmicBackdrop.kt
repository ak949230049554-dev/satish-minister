package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AcUnit
import androidx.compose.material.icons.rounded.Cloud
import androidx.compose.material.icons.rounded.NightsStay
import androidx.compose.material.icons.rounded.Thunderstorm
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.theme.CosmicDeepBg
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.RainIndigo
import com.example.ui.theme.SolarAmber
import kotlin.random.Random

@Composable
fun CosmicBackdrop(modifier: Modifier = Modifier) {
    val stars = remember {
        val rng = Random(42)
        List(70) {
            Triple(rng.nextFloat(), rng.nextFloat(), 0.7f + rng.nextFloat() * 1.8f)
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF070B16),
                    CosmicDeepBg,
                    Color(0xFF0D1426)
                )
            )
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    SolarAmber.copy(alpha = 0.12f),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.85f, size.height * 0.10f),
                radius = size.width * 0.75f
            ),
            center = Offset(size.width * 0.85f, size.height * 0.10f),
            radius = size.width * 0.75f
        )

        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    LunarCyan.copy(alpha = 0.08f),
                    Color.Transparent
                ),
                center = Offset(size.width * 0.15f, size.height * 0.72f),
                radius = size.width * 0.65f
            ),
            center = Offset(size.width * 0.15f, size.height * 0.72f),
            radius = size.width * 0.65f
        )

        stars.forEachIndexed { idx, (xFrac, yFrac, radiusPx) ->
            val alpha = if (idx % 3 == 0) 0.55f else 0.25f
            drawCircle(
                color = Color.White.copy(alpha = alpha),
                radius = radiusPx,
                center = Offset(xFrac * size.width, yFrac * size.height)
            )
        }
    }
}

fun weatherIconForCode(code: Int, isDay: Boolean): Pair<ImageVector, Color> = when (code) {
    0, 1 -> if (isDay) Icons.Rounded.WbSunny to SolarAmber else Icons.Rounded.NightsStay to LunarCyan
    2, 3, 45, 48 -> Icons.Rounded.Cloud to Color(0xFFB7C4E6)
    51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82 -> Icons.Rounded.WaterDrop to RainIndigo
    71, 73, 75, 77, 85, 86 -> Icons.Rounded.AcUnit to LunarCyan
    95, 96, 99 -> Icons.Rounded.Thunderstorm to SolarAmber
    else -> if (isDay) Icons.Rounded.WbSunny to SolarAmber else Icons.Rounded.NightsStay to LunarCyan
}
