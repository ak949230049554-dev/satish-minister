package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Brightness2
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.astronomy.AstronomicalEphemerisEngine
import com.example.data.model.SpaceTelemetry
import com.example.ui.theme.CosmicOutline
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.LunarCyanContainer
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarAmberContainer
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.ui.theme.SuccessEmerald
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpaceScreen(
    telemetry: SpaceTelemetry,
    onNavigateBackToWeather: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler(onBack = onNavigateBackToWeather)

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                SpaceObservatoryHeroBanner(telemetry = telemetry)
            }

            item {
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    val isWide = maxWidth >= 560.dp
                    if (isWide) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            SunDistanceCard(
                                telemetry = telemetry,
                                modifier = Modifier.weight(1f)
                            )
                            MoonDistanceCard(
                                telemetry = telemetry,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            SunDistanceCard(
                                telemetry = telemetry,
                                modifier = Modifier.fillMaxWidth()
                            )
                            MoonDistanceCard(
                                telemetry = telemetry,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }

            item {
                OrbitalVisualizationCard(telemetry = telemetry)
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun SpaceObservatoryHeroBanner(telemetry: SpaceTelemetry) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("space_hero_banner"),
        shape = RoundedCornerShape(26.dp),
        border = BorderStroke(1.dp, CosmicOutline)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(185.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_space_banner),
                contentDescription = stringResource(R.string.space_banner_desc),
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0x55090D1A),
                                Color(0xDD090D1A)
                            )
                        )
                    )
            )
            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = SuccessEmerald.copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, SuccessEmerald.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(SuccessEmerald)
                        )
                        Text(
                            text = "${stringResource(R.string.space_live_badge)} • ${telemetry.liveTimestampHindi}",
                            style = MaterialTheme.typography.labelMedium,
                            color = SuccessEmerald
                        )
                    }
                }
                Text(
                    text = stringResource(R.string.space_header_title),
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                Text(
                    text = "पृथ्वी की कक्षीय गति: ${String.format(Locale.US, "%.2f", telemetry.earthOrbitalSpeedKms)} km/s",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SunDistanceCard(
    telemetry: SpaceTelemetry,
    modifier: Modifier = Modifier
) {
    val formattedKm = AstronomicalEphemerisEngine.formatIndianNumber(telemetry.sunDistanceKm)
    val croreText = String.format(Locale.US, "%.3f करोड़ किमी", telemetry.sunDistanceCroreKm)

    Card(
        modifier = modifier.testTag("sun_distance_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = SolarAmberContainer.copy(alpha = 0.35f)),
        border = BorderStroke(1.dp, SolarAmber.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = SolarAmber.copy(alpha = 0.2f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.WbSunny,
                        contentDescription = stringResource(R.string.space_sun_distance_title),
                        tint = SolarAmber,
                        modifier = Modifier.padding(10.dp)
                    )
                }
                Column {
                    Text(
                        text = stringResource(R.string.space_sun_distance_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = croreText,
                        style = MaterialTheme.typography.labelLarge,
                        color = SolarAmber
                    )
                }
            }

            Text(
                text = "$formattedKm km",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontFamily = SpaceGroteskFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = Color.White
            )

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = CosmicSurface.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, CosmicOutline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.space_light_travel),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = telemetry.sunLightTravelHindi,
                        style = MaterialTheme.typography.titleMedium,
                        color = SolarAmber
                    )
                }
            }
        }
    }
}

@Composable
private fun MoonDistanceCard(
    telemetry: SpaceTelemetry,
    modifier: Modifier = Modifier
) {
    val formattedKm = AstronomicalEphemerisEngine.formatIndianNumber(telemetry.moonDistanceKm)

    Card(
        modifier = modifier.testTag("moon_distance_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = LunarCyanContainer.copy(alpha = 0.4f)),
        border = BorderStroke(1.dp, LunarCyan.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = LunarCyan.copy(alpha = 0.18f)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Brightness2,
                        contentDescription = stringResource(R.string.space_moon_distance_title),
                        tint = LunarCyan,
                        modifier = Modifier.padding(10.dp)
                    )
                }
                Column {
                    Text(
                        text = stringResource(R.string.space_moon_distance_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = telemetry.moonPhaseHindi,
                        style = MaterialTheme.typography.labelLarge,
                        color = LunarCyan
                    )
                }
            }

            Text(
                text = "$formattedKm km",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontFamily = SpaceGroteskFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = Color.White
            )

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.space_moon_phase_title),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "रोशनी ${telemetry.moonIlluminationPercent}%",
                        style = MaterialTheme.typography.labelLarge,
                        color = LunarCyan
                    )
                }
                LinearProgressIndicator(
                    progress = { telemetry.moonIlluminationPercent / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(7.dp)
                        .clip(RoundedCornerShape(999.dp)),
                    color = LunarCyan,
                    trackColor = CosmicSurfaceElevated
                )
            }

            Surface(
                shape = RoundedCornerShape(14.dp),
                color = CosmicSurface.copy(alpha = 0.85f),
                border = BorderStroke(1.dp, CosmicOutline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.space_light_travel),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = telemetry.moonLightTravelHindi,
                        style = MaterialTheme.typography.titleMedium,
                        color = LunarCyan
                    )
                }
            }
        }
    }
}

@Composable
private fun OrbitalVisualizationCard(telemetry: SpaceTelemetry) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CosmicSurface),
        border = BorderStroke(1.dp, CosmicOutline)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.Public,
                    contentDescription = null,
                    tint = LunarCyan
                )
                Text(
                    text = stringResource(R.string.space_orbit_diagram_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
            ) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val earthOrbitRadius = size.minDimension * 0.36f
                val moonOrbitRadius = earthOrbitRadius * 0.36f

                // Sun glow at center
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            SolarAmber,
                            SolarAmber.copy(alpha = 0.35f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = 48f
                    ),
                    center = center,
                    radius = 48f
                )
                drawCircle(
                    color = SolarAmber,
                    radius = 18f,
                    center = center
                )

                // Earth orbit path
                drawCircle(
                    color = CosmicOutline,
                    radius = earthOrbitRadius,
                    center = center,
                    style = Stroke(
                        width = 2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f))
                    )
                )

                val earthRad = Math.toRadians(telemetry.sunOrbitAngleDeg)
                val earthPos = Offset(
                    x = center.x + (earthOrbitRadius * cos(earthRad)).toFloat(),
                    y = center.y + (earthOrbitRadius * sin(earthRad)).toFloat()
                )

                // Line Sun -> Earth
                drawLine(
                    color = SolarAmber.copy(alpha = 0.45f),
                    start = center,
                    end = earthPos,
                    strokeWidth = 2.5f
                )

                // Moon orbit around Earth
                drawCircle(
                    color = LunarCyan.copy(alpha = 0.45f),
                    radius = moonOrbitRadius,
                    center = earthPos,
                    style = Stroke(width = 1.5f)
                )

                val moonRad = Math.toRadians(telemetry.moonOrbitAngleDeg)
                val moonPos = Offset(
                    x = earthPos.x + (moonOrbitRadius * cos(moonRad)).toFloat(),
                    y = earthPos.y + (moonOrbitRadius * sin(moonRad)).toFloat()
                )

                // Earth body
                drawCircle(
                    color = Color(0xFF4F9CFF),
                    radius = 12f,
                    center = earthPos
                )

                // Moon body
                drawCircle(
                    color = LunarCyan,
                    radius = 6.5f,
                    center = moonPos
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                OrbitLegendItem(color = SolarAmber, label = "सूर्य (केंद्र)")
                OrbitLegendItem(color = Color(0xFF4F9CFF), label = "पृथ्वी")
                OrbitLegendItem(color = LunarCyan, label = "चंद्रमा")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Rounded.AutoAwesome,
                    contentDescription = null,
                    tint = SolarAmber,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "नोट: पृथ्वी की अंडाकार कक्षा के कारण सूरज और चांद की दूरी हर सेकंड बदलती रहती है।",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun OrbitLegendItem(color: Color, label: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(10.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
