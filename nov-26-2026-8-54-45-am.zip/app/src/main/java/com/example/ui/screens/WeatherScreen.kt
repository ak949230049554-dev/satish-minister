package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Air
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.CloudQueue
import androidx.compose.material.icons.rounded.LocationOn
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.WaterDrop
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.WbTwilight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.CityLocation
import com.example.data.model.HourlyForecastItem
import com.example.data.model.WeatherReport
import com.example.data.model.WeatherUiState
import com.example.ui.MainUiState
import com.example.ui.components.weatherIconForCode
import com.example.ui.theme.CosmicOutline
import com.example.ui.theme.CosmicSurface
import com.example.ui.theme.CosmicSurfaceElevated
import com.example.ui.theme.LunarCyan
import com.example.ui.theme.RainIndigo
import com.example.ui.theme.RainIndigoContainer
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarAmberContainer
import com.example.ui.theme.SpaceGroteskFontFamily
import com.example.ui.theme.ThermalCool
import com.example.ui.theme.ThermalWarm
import kotlin.math.roundToInt

@Composable
fun WeatherScreen(
    state: MainUiState,
    onSearchQueryChange: (String) -> Unit,
    onSubmitSearch: () -> Unit,
    onClearSearch: () -> Unit,
    onSelectCity: (CityLocation) -> Unit,
    onRefreshWeather: () -> Unit,
    modifier: Modifier = Modifier
) {
    val keyboardController = LocalSoftwareKeyboardController.current

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 840.dp),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                WeatherTopHeader(
                    selectedCity = state.selectedCity,
                    onRefresh = onRefreshWeather
                )
            }

            item {
                CitySearchSection(
                    query = state.searchQuery,
                    isSearching = state.isSearching,
                    results = state.searchResults,
                    searchMessage = state.searchMessageHindi,
                    popularCities = state.popularCities,
                    selectedCity = state.selectedCity,
                    onQueryChange = onSearchQueryChange,
                    onSubmitSearch = {
                        keyboardController?.hide()
                        onSubmitSearch()
                    },
                    onClearSearch = onClearSearch,
                    onSelectCity = { city ->
                        keyboardController?.hide()
                        onSelectCity(city)
                    }
                )
            }

            when (val weatherState = state.weatherState) {
                is WeatherUiState.Loading -> {
                    item {
                        WeatherLoadingCard()
                    }
                }

                is WeatherUiState.Error -> {
                    item {
                        WeatherErrorCard(
                            message = weatherState.messageHindi,
                            onRetry = onRefreshWeather
                        )
                    }
                }

                is WeatherUiState.Success -> {
                    val report = weatherState.report
                    item {
                        HeroWeatherCard(report = report)
                    }
                    item {
                        RainAndSunHighlights(report = report)
                    }
                    item {
                        HourlyForecastSection(hourly = report.hourlyForecast)
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun WeatherTopHeader(
    selectedCity: CityLocation,
    onRefresh: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = stringResource(R.string.app_subtitle),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Surface(
            shape = CircleShape,
            color = CosmicSurfaceElevated,
            border = BorderStroke(1.dp, CosmicOutline)
        ) {
            IconButton(
                onClick = onRefresh,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("refresh_weather_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = stringResource(R.string.weather_refresh),
                    tint = SolarAmber
                )
            }
        }
    }
}

@Composable
private fun CitySearchSection(
    query: String,
    isSearching: Boolean,
    results: List<CityLocation>,
    searchMessage: String?,
    popularCities: List<CityLocation>,
    selectedCity: CityLocation,
    onQueryChange: (String) -> Unit,
    onSubmitSearch: () -> Unit,
    onClearSearch: () -> Unit,
    onSelectCity: (CityLocation) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("city_search_input"),
            placeholder = {
                Text(
                    text = stringResource(R.string.search_city_hint),
                    style = MaterialTheme.typography.bodyMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Rounded.Search,
                    contentDescription = stringResource(R.string.search_button),
                    tint = SolarAmber
                )
            },
            trailingIcon = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isSearching) {
                        CircularProgressIndicator(
                            modifier = Modifier
                                .size(20.dp)
                                .padding(end = 4.dp),
                            strokeWidth = 2.dp,
                            color = LunarCyan
                        )
                    }
                    if (query.isNotEmpty()) {
                        IconButton(
                            onClick = onClearSearch,
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("clear_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Clear,
                                contentDescription = stringResource(R.string.search_clear),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(18.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = CosmicSurface,
                unfocusedContainerColor = CosmicSurface,
                focusedBorderColor = SolarAmber,
                unfocusedBorderColor = CosmicOutline,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { onSubmitSearch() })
        )

        AnimatedVisibility(
            visible = results.isNotEmpty() || searchMessage != null,
            enter = expandVertically(spring()) + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("city_search_results"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CosmicSurfaceElevated),
                border = BorderStroke(1.dp, CosmicOutline)
            ) {
                if (searchMessage != null && results.isEmpty()) {
                    Text(
                        text = searchMessage,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                } else {
                    Column {
                        results.forEachIndexed { index, city ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .minimumInteractiveComponentSize()
                                    .clickable { onSelectCity(city) }
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                                    .testTag("city_result_item_$index"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.LocationOn,
                                    contentDescription = null,
                                    tint = LunarCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = city.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    val sub = listOf(city.region, city.country)
                                        .filter { it.isNotBlank() }
                                        .joinToString(", ")
                                    if (sub.isNotBlank()) {
                                        Text(
                                            text = sub,
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                            if (index < results.lastIndex) {
                                HorizontalDivider(color = CosmicOutline.copy(alpha = 0.5f))
                            }
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            popularCities.forEach { city ->
                val isSelected = city.name == selectedCity.name &&
                    kotlin.math.abs(city.latitude - selectedCity.latitude) < 0.05
                FilterChip(
                    selected = isSelected,
                    onClick = { onSelectCity(city) },
                    label = {
                        Text(
                            text = city.name,
                            style = MaterialTheme.typography.labelLarge
                        )
                    },
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("popular_city_${city.name}"),
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = CosmicSurface,
                        labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                        selectedContainerColor = SolarAmberContainer,
                        selectedLabelColor = SolarAmber
                    ),
                    border = FilterChipDefaults.filterChipBorder(
                        enabled = true,
                        selected = isSelected,
                        borderColor = CosmicOutline,
                        selectedBorderColor = SolarAmber.copy(alpha = 0.6f)
                    )
                )
            }
        }
    }
}

@Composable
private fun HeroWeatherCard(report: WeatherReport) {
    val (weatherIcon, iconColor) = weatherIconForCode(report.weatherCode, report.isDay)
    val thermalAccent = if (report.isWarmThermal) ThermalWarm else ThermalCool

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_weather_card"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        border = BorderStroke(1.dp, CosmicOutline)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        colors = listOf(
                            CosmicSurfaceElevated,
                            CosmicSurface,
                            Color(0xFF151E3B)
                        )
                    )
                )
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.LocationOn,
                                contentDescription = null,
                                tint = SolarAmber,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = report.city.name,
                                style = MaterialTheme.typography.headlineMedium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Text(
                            text = "${report.city.displayName} • अपडेट ${report.updatedAtLabel}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = iconColor.copy(alpha = 0.14f),
                        border = BorderStroke(1.dp, iconColor.copy(alpha = 0.35f))
                    ) {
                        Icon(
                            imageVector = weatherIcon,
                            contentDescription = report.weatherSummaryHindi,
                            tint = iconColor,
                            modifier = Modifier
                                .padding(12.dp)
                                .size(34.dp)
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            text = "${report.currentTempC.roundToInt()}",
                            style = MaterialTheme.typography.displayLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "°C",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontFamily = SpaceGroteskFontFamily
                            ),
                            color = SolarAmber,
                            modifier = Modifier.padding(top = 8.dp, start = 2.dp)
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = report.weatherSummaryHindi,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = thermalAccent.copy(alpha = 0.16f),
                            border = BorderStroke(1.dp, thermalAccent.copy(alpha = 0.45f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Thermostat,
                                    contentDescription = null,
                                    tint = thermalAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = report.thermalComfortHindi,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = thermalAccent
                                )
                            }
                        }
                    }
                }

                HorizontalDivider(color = CosmicOutline.copy(alpha = 0.6f))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricPill(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.Air,
                        iconTint = LunarCyan,
                        label = stringResource(R.string.weather_wind_speed),
                        value = "${report.windSpeedKmh.roundToInt()} km/h",
                        subValue = report.windDirectionHindi
                    )
                    MetricPill(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.Thermostat,
                        iconTint = SolarAmber,
                        label = stringResource(R.string.weather_feels_like),
                        value = "${report.feelsLikeTempC.roundToInt()}°C",
                        subValue = "न्यून ${report.minTempC.roundToInt()}° / अधि ${report.maxTempC.roundToInt()}°"
                    )
                    MetricPill(
                        modifier = Modifier.weight(1f),
                        icon = Icons.Rounded.CloudQueue,
                        iconTint = RainIndigo,
                        label = stringResource(R.string.weather_humidity),
                        value = "${report.humidityPercent}%",
                        subValue = "बादल ${report.cloudCoverPercent}%"
                    )
                }
            }
        }
    }
}

@Composable
private fun MetricPill(
    modifier: Modifier = Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    label: String,
    value: String,
    subValue: String
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = CosmicDeepTint(),
        border = BorderStroke(1.dp, CosmicOutline.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = iconTint,
                    modifier = Modifier.size(15.dp)
                )
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = SpaceGroteskFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subValue,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CosmicDeepTint(): Color = Color(0xFF0E1426)

@Composable
private fun RainAndSunHighlights(report: WeatherReport) {
    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        val isWide = maxWidth >= 540.dp
        if (isWide) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RainForecastCard(report = report, modifier = Modifier.weight(1f))
                SunForecastCard(report = report, modifier = Modifier.weight(1f))
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                RainForecastCard(report = report, modifier = Modifier.fillMaxWidth())
                SunForecastCard(report = report, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun RainForecastCard(
    report: WeatherReport,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.testTag("rain_forecast_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = RainIndigoContainer.copy(alpha = 0.55f)),
        border = BorderStroke(1.dp, RainIndigo.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.WaterDrop,
                        contentDescription = stringResource(R.string.weather_rain_title),
                        tint = RainIndigo
                    )
                    Text(
                        text = stringResource(R.string.weather_rain_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = RainIndigo.copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "${report.nextRainProbabilityPercent}%",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontFamily = SpaceGroteskFontFamily
                        ),
                        color = RainIndigo,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
            }

            Text(
                text = report.rainForecastTitleHindi,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Text(
                text = report.rainForecastDetailHindi,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SunForecastCard(
    report: WeatherReport,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.testTag("sun_forecast_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = SolarAmberContainer.copy(alpha = 0.45f)),
        border = BorderStroke(1.dp, SolarAmber.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.WbSunny,
                        contentDescription = stringResource(R.string.weather_sun_title),
                        tint = SolarAmber
                    )
                    Text(
                        text = stringResource(R.string.weather_sun_title),
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Icon(
                    imageVector = Icons.Rounded.WbTwilight,
                    contentDescription = null,
                    tint = SolarAmber,
                    modifier = Modifier.size(20.dp)
                )
            }

            Text(
                text = report.sunForecastTitleHindi,
                style = MaterialTheme.typography.titleMedium,
                color = Color.White
            )
            Text(
                text = report.sunForecastDetailHindi,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "${stringResource(R.string.weather_sunrise)}: ${report.sunriseTime}",
                    style = MaterialTheme.typography.labelMedium,
                    color = SolarAmber
                )
                Text(
                    text = "${stringResource(R.string.weather_sunset)}: ${report.sunsetTime}",
                    style = MaterialTheme.typography.labelMedium,
                    color = LunarCyan
                )
            }
        }
    }
}

@Composable
private fun HourlyForecastSection(hourly: List<HourlyForecastItem>) {
    if (hourly.isEmpty()) return

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CosmicSurface),
        border = BorderStroke(1.dp, CosmicOutline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.weather_hourly_title),
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "तापमान व बारिश %",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            HourlyTrendCanvas(
                items = hourly.take(12),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(84.dp)
            )

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(hourly) { item ->
                    HourlyItemTile(item = item)
                }
            }
        }
    }
}

@Composable
private fun HourlyTrendCanvas(
    items: List<HourlyForecastItem>,
    modifier: Modifier = Modifier
) {
    if (items.size < 2) return
    val minTemp = items.minOf { it.temperatureC }
    val maxTemp = items.maxOf { it.temperatureC }
    val tempRange = (maxTemp - minTemp).coerceAtLeast(1.0)

    Canvas(modifier = modifier) {
        val stepX = size.width / (items.size - 1).toFloat()
        val topPad = 14f
        val bottomPad = 18f
        val chartHeight = (size.height - topPad - bottomPad).coerceAtLeast(10f)

        val linePath = Path()
        items.forEachIndexed { idx, item ->
            val x = idx * stepX
            val rainBarHeight = (item.rainProbabilityPercent / 100f) * (chartHeight * 0.65f)
            if (rainBarHeight > 2f) {
                drawLine(
                    color = RainIndigo.copy(alpha = 0.35f),
                    start = Offset(x, size.height - bottomPad),
                    end = Offset(x, size.height - bottomPad - rainBarHeight),
                    strokeWidth = 10f,
                    cap = StrokeCap.Round
                )
            }

            val normTemp = ((item.temperatureC - minTemp) / tempRange).toFloat()
            val y = topPad + (1f - normTemp) * chartHeight
            if (idx == 0) linePath.moveTo(x, y) else linePath.lineTo(x, y)
        }

        drawPath(
            path = linePath,
            color = SolarAmber,
            style = Stroke(width = 4.5f, cap = StrokeCap.Round)
        )

        items.forEachIndexed { idx, item ->
            val x = idx * stepX
            val normTemp = ((item.temperatureC - minTemp) / tempRange).toFloat()
            val y = topPad + (1f - normTemp) * chartHeight
            drawCircle(
                color = SolarAmber,
                radius = 5.5f,
                center = Offset(x, y)
            )
        }
    }
}

@Composable
private fun HourlyItemTile(item: HourlyForecastItem) {
    val (icon, tint) = weatherIconForCode(item.weatherCode, item.isDay)
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = CosmicSurfaceElevated,
        border = BorderStroke(1.dp, CosmicOutline.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier
                .width(90.dp)
                .padding(horizontal = 8.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = item.hourLabel,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = tint,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = "${item.temperatureC.roundToInt()}°C",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontFamily = SpaceGroteskFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "💧 ${item.rainProbabilityPercent}%",
                style = MaterialTheme.typography.labelMedium,
                color = RainIndigo
            )
            Text(
                text = "${item.windSpeedKmh.roundToInt()} km/h",
                style = MaterialTheme.typography.labelMedium,
                color = LunarCyan
            )
        }
    }
}

@Composable
private fun WeatherLoadingCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CosmicSurface),
        border = BorderStroke(1.dp, CosmicOutline)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CircularProgressIndicator(color = SolarAmber)
            Text(
                text = stringResource(R.string.weather_loading),
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun WeatherErrorCard(
    message: String,
    onRetry: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = CosmicSurface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = stringResource(R.string.weather_error_title),
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.error
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(
                onClick = onRetry,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("retry_weather_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = SolarAmber,
                    contentColor = Color(0xFF1F1400)
                )
            ) {
                Text(text = stringResource(R.string.weather_retry))
            }
        }
    }
}
