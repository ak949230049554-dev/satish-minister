package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CosmicDeepBg = Color(0xFF090D1A)
val CosmicSurface = Color(0xFF12182B)
val CosmicSurfaceElevated = Color(0xFF1A223D)
val CosmicOutline = Color(0xFF2B375E)

val SolarAmber = Color(0xFFFFB84D)
val SolarAmberDark = Color(0xFF3A2600)
val SolarAmberContainer = Color(0xFF473000)

val LunarCyan = Color(0xFF5CE1E6)
val LunarCyanContainer = Color(0xFF0A3640)

val RainIndigo = Color(0xFF7B9BFF)
val RainIndigoContainer = Color(0xFF1C2952)

val ThermalWarm = Color(0xFFFF7A59)
val ThermalCool = Color(0xFF4DD0E1)
val SuccessEmerald = Color(0xFF4ADE80)
val ErrorCoral = Color(0xFFFF6B6B)

val TextIvory = Color(0xFFF4F6FC)
val TextSlate = Color(0xFF9AA6C8)
