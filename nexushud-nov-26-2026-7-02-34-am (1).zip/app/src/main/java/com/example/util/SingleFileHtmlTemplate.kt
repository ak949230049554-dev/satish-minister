package com.example.util

object SingleFileHtmlTemplate {
    val htmlSource: String = """
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" />
<title>NexusHUD // ARM64 Mod Menu Simulator</title>
<style>
:root{--bg:#06070b;--glass:rgba(14,17,26,.88);--red:#ff1e42;--cyan:#00f0ff;--green:#39ff88;--border:#262d40;--txt:#f2f5fa;--muted:#8c96b0}
*{box-sizing:border-box;user-select:none;-webkit-tap-highlight-color:transparent}
html,body{margin:0;width:100%;height:100%;overflow:hidden;background:var(--bg);color:var(--txt);font-family:system-ui,-apple-system,monospace}
canvas{position:fixed;inset:0;width:100%;height:100%;display:block}
#login{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:radial-gradient(circle at top,#1a0a14,#06070b 70%);z-index:50;padding:20px}
.card{width:100%;max-width:360px;background:var(--glass);backdrop-filter:blur(16px);border:1px solid var(--red);border-radius:16px;padding:22px;box-shadow:0 0 32px rgba(255,30,66,.25)}
h1{margin:0 0 6px;font-size:22px;letter-spacing:2px;color:var(--cyan)}
.sub{font-size:11px;color:var(--muted);margin-bottom:16px}
input{width:100%;padding:12px;border-radius:10px;border:1px solid var(--border);background:#090b11;color:var(--cyan);font-family:monospace;font-size:13px;outline:none;margin-bottom:12px}
.row{display:flex;gap:10px}
button{cursor:pointer;border:none;border-radius:10px;padding:12px 14px;font-weight:700;letter-spacing:1px;font-size:12px}
.btn-cyan{background:rgba(0,240,255,.14);border:1px solid var(--cyan);color:var(--cyan);flex:1}
.btn-red{background:linear-gradient(135deg,var(--red),#b80d2b);color:#fff;flex:1.4;box-shadow:0 0 18px rgba(255,30,66,.4)}
#err{color:var(--red);font-size:11px;min-height:16px;margin-top:8px}
#fpsHud{position:fixed;top:12px;left:50%;transform:translateX(-50%);display:none;gap:14px;padding:6px 14px;border-radius:999px;background:var(--glass);border:1px solid var(--cyan);font-size:11px;z-index:15;box-shadow:0 0 16px rgba(0,240,255,.2)}
#bubble{position:fixed;left:18px;top:76px;width:54px;height:54px;border-radius:50%;background:radial-gradient(circle,#1b2133,#0a0c12);border:2px solid var(--cyan);box-shadow:0 0 18px rgba(0,240,255,.45),inset 0 0 10px rgba(255,30,66,.4);display:none;align-items:center;justify-content:center;z-index:40;touch-action:none;color:var(--cyan);font-weight:800;font-size:11px}
#menu{position:fixed;left:16px;top:140px;width:min(340px,calc(100vw - 32px));max-height:74vh;background:var(--glass);backdrop-filter:blur(18px);border:1px solid var(--border);border-top:2px solid var(--red);border-radius:16px;display:none;flex-direction:column;z-index:35;box-shadow:0 16px 48px rgba(0,0,0,.75)}
.hdr{display:flex;justify-content:space-between;align-items:center;padding:12px 14px;border-bottom:1px solid var(--border)}
.body{overflow-y:auto;padding:12px 14px;display:flex;flex-direction:column;gap:10px}
.opt{display:flex;justify-content:space-between;align-items:center;background:#111521;border:1px solid var(--border);border-radius:10px;padding:10px 12px;font-size:12px}
input[type=range]{width:100%;accent-color:var(--cyan);margin:4px 0}
.term{background:#050609;border:1px solid #1d2333;border-radius:10px;padding:8px;height:110px;overflow-y:auto;font-size:10px;line-height:1.45;color:var(--green)}
</style>
</head>
<body>
<canvas id="arena"></canvas>
<div id="fpsHud"><span id="fpsVal">120 FPS</span><span id="pingVal">14 ms</span><span style="color:var(--green)">ANTI-LAG ON</span></div>
<div id="login">
  <div class="card">
    <h1>NEXUS // OVERLAY</h1>
    <div class="sub">ARM64 TACTICAL UTILITY SIMULATOR</div>
    <input id="keyInput" placeholder="NXS-VIP-XXXX-ARM64-PRO" />
    <div class="row">
      <button class="btn-cyan" onclick="getKey()">GET KEY</button>
      <button class="btn-red" onclick="verifyKey()">ACTIVATE VIP</button>
    </div>
    <div id="err"></div>
  </div>
</div>
<div id="bubble">NXS</div>
<div id="menu">
  <div class="hdr">
    <strong style="color:var(--cyan);font-size:13px">NEXUS MOD MENU</strong>
    <button style="padding:4px 10px;background:#1c2233;color:#fff" onclick="toggleMenu()">_</button>
  </div>
  <div class="body">
    <label class="opt"><span>ESP Box &amp; HP Info</span><input type="checkbox" id="tEsp" checked></label>
    <label class="opt"><span>Aimbot &amp; FOV Circle</span><input type="checkbox" id="tAim" checked></label>
    <div class="opt" style="flex-direction:column;align-items:stretch">
      <div style="display:flex;justify-content:space-between"><span>FOV Radius</span><span id="fovLbl">95px</span></div>
      <input type="range" id="sFov" min="45" max="180" value="95" oninput="fovLbl.textContent=this.value+'px'">
      <div style="display:flex;justify-content:space-between"><span>Aim Smoothness</span><span id="smLbl">4.5x</span></div>
      <input type="range" id="sSm" min="1" max="10" step="0.5" value="4.5" oninput="smLbl.textContent=this.value+'x'">
    </div>
    <label class="opt"><span>Custom Pro Crosshair</span><input type="checkbox" id="tCross" checked></label>
    <label class="opt"><span>120 FPS &amp; Anti-Lag</span><input type="checkbox" id="tFps" checked></label>
    <div class="term" id="term">[SYS] Python hook sandbox ready.<br></div>
    <button class="btn-red" id="injBtn" onclick="injectPython()">INJECT PYTHON BYPASS</button>
  </div>
</div>
<script>
const c=document.getElementById('arena'),ctx=c.getContext('2d');
let W=c.width=innerWidth,H=c.height=innerHeight;onresize=()=>{W=c.width=innerWidth;H=c.height=innerHeight};
const bots=[{x:.25,y:.38,vx:.16,vy:.08,hp:.85,n:'BOT_ALPHA'},{x:.72,y:.45,vx:-.18,vy:.09,hp:.52,n:'VIPER_02'},{x:.52,y:.28,vx:.12,vy:-.09,hp:.3,n:'GHOST_X'}];
function getKey(){keyInput.value='NXS-VIP-'+Math.floor(1000+Math.random()*8999)+'-ARM64-PRO';err.textContent=''}
function verifyKey(){if(keyInput.value.trim().length<8){err.textContent='Enter or generate a valid VIP key.';return}login.style.display='none';bubble.style.display='flex';menu.style.display='flex';fpsHud.style.display='flex';loop()}
function toggleMenu(){menu.style.display=menu.style.display==='none'?'flex':'none'}
let drag=false,dx=0,dy=0,moved=false;
bubble.addEventListener('pointerdown',e=>{drag=true;moved=false;dx=e.clientX-bubble.offsetLeft;dy=e.clientY-bubble.offsetTop;bubble.setPointerCapture(e.pointerId)});
bubble.addEventListener('pointermove',e=>{if(!drag)return;moved=true;bubble.style.left=Math.max(8,Math.min(W-62,e.clientX-dx))+'px';bubble.style.top=Math.max(8,Math.min(H-62,e.clientY-dy))+'px'});
bubble.addEventListener('pointerup',()=>{drag=false;if(!moved)toggleMenu()});
function log(t,col='#39ff88'){const d=document.createElement('div');d.style.color=col;d.textContent=t;term.appendChild(d);term.scrollTop=term.scrollHeight}
function injectPython(){
  injBtn.disabled=true;injBtn.textContent='INJECTING...';
  const s=[['$ python3 core_hook.py --arch arm64-v8a','#00f0ff'],['[*] Loading pymem & frida bindings...','#f2f5fa'],['[+] libil2cpp.so base @ 0x7B4E200000','#39ff88'],['[*] Patching anti-cheat CRC32 checksums...','#ffb800'],['[SUCCESS!] BYPASS INJECTED.','#39ff88']];
  s.forEach((x,i)=>setTimeout(()=>{log(x[0],x[1]);if(i===s.length-1){injBtn.disabled=false;injBtn.textContent='INJECT PYTHON BYPASS'}},i*320));
}
let f=0;
function loop(){
  f++;ctx.fillStyle='#06070b';ctx.fillRect(0,0,W,H);
  ctx.strokeStyle='rgba(0,240,255,0.08)';
  for(let x=0;x<W;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke()}
  for(let y=0;y<H;y+=40){ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(W,y);ctx.stroke()}
  const cx=W/2,cy=H/2,fov=+sFov.value;
  if(tAim.checked){ctx.strokeStyle='rgba(0,240,255,0.75)';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(cx,cy,fov,0,Math.PI*2);ctx.stroke()}
  bots.forEach(b=>{
    b.x+=b.vx*0.016;b.y+=b.vy*0.016;if(b.x<.15||b.x>.85)b.vx*=-1;if(b.y<.2||b.y>.78)b.vy*=-1;
    const px=b.x*W,py=b.y*H,inFov=Math.hypot(px-cx,py-cy)<=fov;
    if(tEsp.checked){
      ctx.strokeStyle=inFov&&tAim.checked?'#00f0ff':'#ff1e42';ctx.lineWidth=2;ctx.strokeRect(px-18,py-32,36,64);
      ctx.fillStyle='#111';ctx.fillRect(px-18,py-40,36,5);ctx.fillStyle=b.hp>.5?'#39ff88':'#ff1e42';ctx.fillRect(px-18,py-40,36*b.hp,5);
      ctx.fillStyle='#fff';ctx.font='10px monospace';ctx.fillText(b.n,px-24,py-46);
    }
    if(tAim.checked&&inFov){ctx.strokeStyle='rgba(0,240,255,0.5)';ctx.beginPath();ctx.moveTo(cx,cy);ctx.lineTo(px,py-18);ctx.stroke()}
  });
  if(tCross.checked){ctx.strokeStyle='#ff1e42';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(cx-12,cy);ctx.lineTo(cx-4,cy);ctx.moveTo(cx+4,cy);ctx.lineTo(cx+12,cy);ctx.moveTo(cx,cy-12);ctx.lineTo(cx,cy-4);ctx.moveTo(cx,cy+4);ctx.lineTo(cx,cy+12);ctx.stroke()}
  fpsHud.style.display=tFps.checked?'flex':'none';
  if(f%15===0){fpsVal.textContent=(tFps.checked?118+Math.floor(Math.random()*3):58)+' FPS';pingVal.textContent=(tFps.checked?13+Math.floor(Math.random()*5):48)+' ms'}
  requestAnimationFrame(loop);
}
</script>
</body>
</html>
    """.trimIndent()
}
