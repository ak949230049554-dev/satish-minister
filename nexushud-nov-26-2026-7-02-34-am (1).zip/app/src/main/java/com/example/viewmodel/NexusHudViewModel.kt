package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.BypassState
import com.example.model.CrosshairStyle
import com.example.model.ModMenuUiState
import com.example.model.TerminalLine
import com.example.model.TerminalLogLevel
import com.example.model.initialTerminalLogs
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.random.Random

class NexusHudViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(ModMenuUiState())
    val uiState: StateFlow<ModMenuUiState> = _uiState.asStateFlow()

    private var simulationJob: Job? = null
    private var injectionJob: Job? = null
    private var logCounter = 3

    fun onKeyInputChanged(value: String) {
        _uiState.update {
            it.copy(
                activationKey = value.uppercase(),
                keyError = null
            )
        }
    }

    fun generateVipKey() {
        val hexPart = (1000..9999).random()
        val generated = "NXS-VIP-$hexPart-ARM64-PRO"
        _uiState.update {
            it.copy(
                activationKey = generated,
                keyError = null
            )
        }
    }

    fun verifyAndActivate() {
        val key = _uiState.value.activationKey.trim()
        if (key.isEmpty()) {
            _uiState.update {
                it.copy(keyError = "Activation key required. Tap GET KEY to generate a VIP license.")
            }
            return
        }
        if (key.length < 8) {
            _uiState.update {
                it.copy(keyError = "Invalid license signature. Key must be at least 8 characters.")
            }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isVerifyingKey = true, keyError = null) }
            delay(420)
            _uiState.update {
                it.copy(
                    isVerifyingKey = false,
                    isAuthenticated = true,
                    isMenuExpanded = true
                )
            }
            appendLog("[AUTH] VIP License verified: $key", TerminalLogLevel.SUCCESS)
            startSimulationLoop()
        }
    }

    fun lockSession() {
        simulationJob?.cancel()
        injectionJob?.cancel()
        _uiState.update {
            it.copy(
                isAuthenticated = false,
                isVerifyingKey = false,
                bypassState = BypassState.IDLE
            )
        }
    }

    fun toggleMenuExpanded() {
        _uiState.update { it.copy(isMenuExpanded = !it.isMenuExpanded) }
    }

    fun setMenuExpanded(expanded: Boolean) {
        _uiState.update { it.copy(isMenuExpanded = expanded) }
    }

    fun toggleEsp(enabled: Boolean) {
        _uiState.update { it.copy(espEnabled = enabled) }
        appendLog(
            "[ESP] Entity Bounding Box & HP HUD -> ${if (enabled) "ENABLED" else "DISABLED"}",
            if (enabled) TerminalLogLevel.INFO else TerminalLogLevel.WARN
        )
    }

    fun toggleEspSnaplines(enabled: Boolean) {
        _uiState.update { it.copy(espSnaplines = enabled) }
    }

    fun toggleAimbot(enabled: Boolean) {
        _uiState.update { it.copy(aimbotEnabled = enabled) }
        appendLog(
            "[AIM] FOV & Magnetic Assist -> ${if (enabled) "ARMED" else "STANDBY"}",
            if (enabled) TerminalLogLevel.INFO else TerminalLogLevel.WARN
        )
    }

    fun updateFovRadius(radius: Float) {
        _uiState.update { it.copy(aimbotFovRadius = radius.coerceIn(45f, 180f)) }
    }

    fun updateSmoothness(smoothness: Float) {
        _uiState.update { it.copy(aimbotSmoothness = smoothness.coerceIn(1f, 10f)) }
    }

    fun toggleCrosshair(enabled: Boolean) {
        _uiState.update { it.copy(crosshairEnabled = enabled) }
    }

    fun selectCrosshairStyle(style: CrosshairStyle) {
        _uiState.update { it.copy(crosshairStyle = style) }
    }

    fun toggleFpsBoost(enabled: Boolean) {
        _uiState.update { it.copy(fpsBoostEnabled = enabled) }
        appendLog(
            "[GPU] 120Hz Frame Unlocker & Anti-Lag -> ${if (enabled) "ACTIVE (120 FPS)" else "STOCK (60 FPS)"}",
            if (enabled) TerminalLogLevel.SUCCESS else TerminalLogLevel.WARN
        )
    }

    fun setHtmlExportDialogVisible(visible: Boolean) {
        _uiState.update { it.copy(showHtmlExportDialog = visible) }
    }

    fun clearLogs() {
        logCounter = 1
        _uiState.update {
            it.copy(
                terminalLogs = listOf(
                    TerminalLine(
                        id = logCounter++,
                        timestamp = formatStamp(0),
                        text = "[SYS] Console buffer cleared.",
                        level = TerminalLogLevel.INFO
                    )
                )
            )
        }
    }

    fun injectPythonBypass() {
        if (_uiState.value.bypassState == BypassState.INJECTING) return

        injectionJob?.cancel()
        injectionJob = viewModelScope.launch {
            _uiState.update { it.copy(bypassState = BypassState.INJECTING) }

            val steps = listOf(
                Triple(120L, "$ python3 core_hook.py --arch arm64-v8a --pid 18492", TerminalLogLevel.CMD),
                Triple(260L, "[*] Loading pymem_android & frida-gum bindings (v16.2.1)...", TerminalLogLevel.INFO),
                Triple(280L, "[*] Attaching ptrace(PTRACE_ATTACH) -> com.tactical.arena.arm64", TerminalLogLevel.INFO),
                Triple(320L, "[+] Mapped libil2cpp.so base offset @ 0x7B4E200000 [r-xp]", TerminalLogLevel.HEX),
                Triple(340L, "[+] Pattern scan AOB_ENTITY_LIST -> 0x02F8A410 (match 1/1)", TerminalLogLevel.HEX),
                Triple(310L, "[+] Located anti-cheat module: libtersafe.so @ 0x7A9104C000", TerminalLogLevel.HEX),
                Triple(350L, "[*] Patching CRC32 integrity checks [0x0041C2B0 -> 1F 20 03 D5]", TerminalLogLevel.WARN),
                Triple(300L, "[*] Hooking PlayerController::GetHealth() & WorldToScreen()...", TerminalLogLevel.INFO),
                Triple(260L, "[✓] VTable trampoline verified (0x04 memory hooks active).", TerminalLogLevel.INFO),
                Triple(220L, "[SUCCESS!] PYTHON MEMORY BYPASS ACTIVE — ALL MODULES ARMED.", TerminalLogLevel.SUCCESS)
            )

            for ((waitMs, msg, level) in steps) {
                delay(waitMs)
                appendLog(msg, level)
            }

            _uiState.update { it.copy(bypassState = BypassState.ACTIVE) }
        }
    }

    private fun startSimulationLoop() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            var tick = 0
            while (isActive) {
                delay(32L) // ~30Hz simulation step for smooth Compose animation
                tick++
                _uiState.update { state ->
                    val updatedEnemies = state.enemies.mapIndexed { idx, enemy ->
                        var nextX = enemy.normX + enemy.vx * 0.032f
                        var nextVx = enemy.vx
                        if (nextX < 0.14f || nextX > 0.86f) {
                            nextVx = -nextVx
                            nextX = nextX.coerceIn(0.14f, 0.86f)
                        }

                        var nextY = enemy.normY + enemy.vy * 0.032f
                        var nextVy = enemy.vy
                        if (nextY < 0.22f || nextY > 0.78f) {
                            nextVy = -nextVy
                            nextY = nextY.coerceIn(0.22f, 0.78f)
                        }

                        val distJitter = if (tick % 18 == idx) {
                            (18 + ((1f - nextY) * 52).toInt()).coerceIn(12, 85)
                        } else {
                            enemy.distanceM
                        }

                        val hpDelta = if (tick % 45 == idx * 7) {
                            val shift = Random.nextFloat() * 0.12f - 0.05f
                            (enemy.hp + shift).coerceIn(0.18f, 1.0f)
                        } else {
                            enemy.hp
                        }

                        enemy.copy(
                            normX = nextX,
                            normY = nextY,
                            vx = nextVx,
                            vy = nextVy,
                            distanceM = distJitter,
                            hp = hpDelta
                        )
                    }

                    val updateTelemetry = tick % 10 == 0
                    val fps = if (updateTelemetry) {
                        if (state.fpsBoostEnabled) Random.nextInt(118, 121)
                        else Random.nextInt(55, 61)
                    } else state.currentFps

                    val ping = if (updateTelemetry) {
                        if (state.fpsBoostEnabled) Random.nextInt(12, 19)
                        else Random.nextInt(42, 64)
                    } else state.currentPingMs

                    val frameMs = if (updateTelemetry) {
                        if (state.fpsBoostEnabled) 1000f / fps.toFloat()
                        else 1000f / fps.toFloat()
                    } else state.frameTimeMs

                    state.copy(
                        enemies = updatedEnemies,
                        currentFps = fps,
                        currentPingMs = ping,
                        frameTimeMs = frameMs
                    )
                }
            }
        }
    }

    private fun appendLog(text: String, level: TerminalLogLevel) {
        val nextId = logCounter++
        val stamp = formatStamp(nextId)
        _uiState.update { state ->
            val updated = (state.terminalLogs + TerminalLine(nextId, stamp, text, level)).takeLast(40)
            state.copy(terminalLogs = updated)
        }
    }

    private fun formatStamp(step: Int): String {
        val sec = (step * 2) % 60
        val ms = abs((step * 17) % 99)
        return String.format("00:%02d.%02d", sec, ms)
    }

    override fun onCleared() {
        super.onCleared()
        simulationJob?.cancel()
        injectionJob?.cancel()
    }
}
