package com.example.model

enum class CrosshairStyle(val label: String) {
    TACTICAL_PLUS("TACTICAL +"),
    CYBER_DOT("CYBER DOT"),
    DYNAMIC_X("DYNAMIC X")
}

enum class TerminalLogLevel {
    CMD,
    INFO,
    HEX,
    WARN,
    SUCCESS
}

data class TerminalLine(
    val id: Int,
    val timestamp: String,
    val text: String,
    val level: TerminalLogLevel
)

data class SimEnemy(
    val id: String,
    val name: String,
    val normX: Float,
    val normY: Float,
    val vx: Float,
    val vy: Float,
    val hp: Float,
    val distanceM: Int
)

enum class BypassState {
    IDLE,
    INJECTING,
    ACTIVE
}

data class ModMenuUiState(
    val isAuthenticated: Boolean = false,
    val activationKey: String = "",
    val isVerifyingKey: Boolean = false,
    val keyError: String? = null,
    val isMenuExpanded: Boolean = true,
    val espEnabled: Boolean = true,
    val espSnaplines: Boolean = true,
    val aimbotEnabled: Boolean = true,
    val aimbotFovRadius: Float = 96f,
    val aimbotSmoothness: Float = 4.5f,
    val crosshairEnabled: Boolean = true,
    val crosshairStyle: CrosshairStyle = CrosshairStyle.TACTICAL_PLUS,
    val fpsBoostEnabled: Boolean = true,
    val currentFps: Int = 120,
    val currentPingMs: Int = 15,
    val frameTimeMs: Float = 8.3f,
    val bypassState: BypassState = BypassState.IDLE,
    val terminalLogs: List<TerminalLine> = initialTerminalLogs(),
    val enemies: List<SimEnemy> = initialSimEnemies(),
    val showHtmlExportDialog: Boolean = false
)

fun initialTerminalLogs(): List<TerminalLine> = listOf(
    TerminalLine(1, "00:00.01", "[SYS] NexusHUD v4.2 ARM64 sandbox initialized.", TerminalLogLevel.INFO),
    TerminalLine(2, "00:00.04", "[MEM] Waiting for Python bypass hook injection...", TerminalLogLevel.WARN)
)

fun initialSimEnemies(): List<SimEnemy> = listOf(
    SimEnemy("e1", "BOT_ALPHA", 0.28f, 0.38f, 0.14f, 0.06f, 0.88f, 24),
    SimEnemy("e2", "VIPER_02", 0.68f, 0.44f, -0.17f, 0.08f, 0.54f, 39),
    SimEnemy("e3", "GHOST_X", 0.50f, 0.30f, 0.11f, -0.07f, 0.29f, 58),
    SimEnemy("e4", "RECON_9", 0.78f, 0.62f, -0.12f, -0.09f, 0.96f, 19)
)
