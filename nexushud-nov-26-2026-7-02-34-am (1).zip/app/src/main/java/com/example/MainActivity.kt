package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SimulationArenaOverlay
import com.example.ui.theme.NexusHudTheme
import com.example.viewmodel.NexusHudViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent {
            NexusHudTheme {
                val viewModel: NexusHudViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                if (uiState.isAuthenticated) {
                    BackHandler {
                        if (uiState.isMenuExpanded) {
                            viewModel.setMenuExpanded(false)
                        } else {
                            viewModel.lockSession()
                        }
                    }
                }

                Crossfade(
                    targetState = uiState.isAuthenticated,
                    animationSpec = tween(durationMillis = 320),
                    label = "auth_crossfade"
                ) { authenticated ->
                    if (!authenticated) {
                        LoginScreen(
                            uiState = uiState,
                            onKeyChange = viewModel::onKeyInputChanged,
                            onGetKeyClick = viewModel::generateVipKey,
                            onActivateClick = viewModel::verifyAndActivate
                        )
                    } else {
                        SimulationArenaOverlay(
                            uiState = uiState,
                            onToggleMenu = viewModel::toggleMenuExpanded,
                            onCollapseMenu = { viewModel.setMenuExpanded(false) },
                            onLockSession = viewModel::lockSession,
                            onToggleEsp = viewModel::toggleEsp,
                            onToggleEspSnaplines = viewModel::toggleEspSnaplines,
                            onToggleAimbot = viewModel::toggleAimbot,
                            onFovChange = viewModel::updateFovRadius,
                            onSmoothnessChange = viewModel::updateSmoothness,
                            onToggleCrosshair = viewModel::toggleCrosshair,
                            onSelectCrosshairStyle = viewModel::selectCrosshairStyle,
                            onToggleFpsBoost = viewModel::toggleFpsBoost,
                            onClearLogs = viewModel::clearLogs,
                            onInjectBypass = viewModel::injectPythonBypass,
                            onOpenHtmlDialog = { viewModel.setHtmlExportDialogVisible(true) },
                            onDismissHtmlDialog = { viewModel.setHtmlExportDialogVisible(false) }
                        )
                    }
                }
            }
        }
    }
}
