package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DragIndicator
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Minimize
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.BypassState
import com.example.model.CrosshairStyle
import com.example.model.ModMenuUiState
import com.example.model.TerminalLogLevel
import com.example.ui.components.CyberCrosshairSelector
import com.example.ui.components.CyberSliderRow
import com.example.ui.components.CyberToggleRow
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberGlass
import com.example.ui.theme.CyberVoid
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.SingleFileHtmlTemplate

@Composable
fun ModMenuOverlayPanel(
    uiState: ModMenuUiState,
    maxPanelHeight: Dp,
    onDragPanel: (Offset) -> Unit,
    onCollapse: () -> Unit,
    onLockSession: () -> Unit,
    onToggleEsp: (Boolean) -> Unit,
    onToggleEspSnaplines: (Boolean) -> Unit,
    onToggleAimbot: (Boolean) -> Unit,
    onFovChange: (Float) -> Unit,
    onSmoothnessChange: (Float) -> Unit,
    onToggleCrosshair: (Boolean) -> Unit,
    onSelectCrosshairStyle: (CrosshairStyle) -> Unit,
    onToggleFpsBoost: (Boolean) -> Unit,
    onClearLogs: () -> Unit,
    onInjectBypass: () -> Unit,
    onOpenHtmlDialog: () -> Unit,
    onDismissHtmlDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val terminalListState = rememberLazyListState()

    LaunchedEffect(uiState.terminalLogs.size) {
        if (uiState.terminalLogs.isNotEmpty()) {
            terminalListState.animateScrollToItem(uiState.terminalLogs.lastIndex)
        }
    }

    Column(
        modifier = modifier
            .widthIn(max = 360.dp)
            .fillMaxWidth()
            .heightIn(max = maxPanelHeight)
            .clip(RoundedCornerShape(18.dp))
            .background(CyberGlass)
            .border(
                width = 1.5.dp,
                brush = Brush.verticalGradient(
                    listOf(NeonCrimson, CyberBorder, ElectricCyan.copy(alpha = 0.7f))
                ),
                shape = RoundedCornerShape(18.dp)
            )
    ) {
        // Draggable ImGui-style Header Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.horizontalGradient(
                        listOf(NeonCrimson.copy(alpha = 0.2f), CyberCard, ElectricCyan.copy(alpha = 0.14f))
                    )
                )
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDragPanel(dragAmount)
                    }
                }
                .padding(start = 10.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Filled.DragIndicator,
                contentDescription = null,
                tint = TextSecondary,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stringResource(R.string.menu_title),
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val statusColor = when (uiState.bypassState) {
                        BypassState.ACTIVE -> TerminalGreen
                        BypassState.INJECTING -> NeonAmber
                        BypassState.IDLE -> NeonCrimson
                    }
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = if (uiState.bypassState == BypassState.ACTIVE) {
                            stringResource(R.string.hud_bypass_armed)
                        } else {
                            stringResource(R.string.menu_subtitle)
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            IconButton(
                onClick = onOpenHtmlDialog,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("export_html_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Code,
                    contentDescription = stringResource(R.string.btn_export_html),
                    tint = ElectricCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onLockSession,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("lock_session_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = stringResource(R.string.btn_lock_session),
                    tint = NeonCrimson,
                    modifier = Modifier.size(18.dp)
                )
            }

            IconButton(
                onClick = onCollapse,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .testTag("collapse_menu_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Minimize,
                    contentDescription = stringResource(R.string.menu_collapse_desc),
                    tint = TextPrimary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }

        HorizontalDivider(color = CyberBorder, thickness = 1.dp)

        // Scrollable Utility Modules
        Column(
            modifier = Modifier
                .weight(1f, fill = false)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CyberToggleRow(
                title = stringResource(R.string.feature_esp_title),
                subtitle = stringResource(R.string.feature_esp_desc),
                icon = Icons.Filled.Visibility,
                checked = uiState.espEnabled,
                accentColor = NeonCrimson,
                testTagName = "toggle_esp",
                onCheckedChange = onToggleEsp
            )

            AnimatedVisibility(visible = uiState.espEnabled) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberCard)
                        .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
                        .clickable { onToggleEspSnaplines(!uiState.espSnaplines) }
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                        .testTag("toggle_esp_snaplines"),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ESP Top Snaplines",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Text(
                        text = if (uiState.espSnaplines) "ON" else "OFF",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (uiState.espSnaplines) ElectricCyan else TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            CyberToggleRow(
                title = stringResource(R.string.feature_aimbot_title),
                subtitle = stringResource(R.string.feature_aimbot_desc),
                icon = Icons.Filled.CenterFocusStrong,
                checked = uiState.aimbotEnabled,
                accentColor = ElectricCyan,
                testTagName = "toggle_aimbot",
                onCheckedChange = onToggleAimbot
            )

            AnimatedVisibility(visible = uiState.aimbotEnabled) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    CyberSliderRow(
                        label = stringResource(R.string.slider_fov_label),
                        valueText = "${uiState.aimbotFovRadius.toInt()} dp",
                        value = uiState.aimbotFovRadius,
                        valueRange = 45f..180f,
                        accentColor = ElectricCyan,
                        testTagName = "slider_fov",
                        onValueChange = onFovChange
                    )
                    CyberSliderRow(
                        label = stringResource(R.string.slider_smooth_label),
                        valueText = String.format("%.1fx", uiState.aimbotSmoothness),
                        value = uiState.aimbotSmoothness,
                        valueRange = 1f..10f,
                        accentColor = NeonCrimson,
                        testTagName = "slider_smoothness",
                        onValueChange = onSmoothnessChange
                    )
                }
            }

            CyberToggleRow(
                title = stringResource(R.string.feature_crosshair_title),
                subtitle = stringResource(R.string.feature_crosshair_desc),
                icon = Icons.Filled.GpsFixed,
                checked = uiState.crosshairEnabled,
                accentColor = NeonCrimson,
                testTagName = "toggle_crosshair",
                onCheckedChange = onToggleCrosshair
            )

            AnimatedVisibility(visible = uiState.crosshairEnabled) {
                CyberCrosshairSelector(
                    selectedStyle = uiState.crosshairStyle,
                    onSelect = onSelectCrosshairStyle
                )
            }

            CyberToggleRow(
                title = stringResource(R.string.feature_fps_title),
                subtitle = stringResource(R.string.feature_fps_desc),
                icon = Icons.Filled.Speed,
                checked = uiState.fpsBoostEnabled,
                accentColor = TerminalGreen,
                testTagName = "toggle_fps_boost",
                onCheckedChange = onToggleFpsBoost
            )
        }

        HorizontalDivider(color = CyberBorder, thickness = 1.dp)

        // Bottom Python & Memory Injection Terminal Section
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(CyberVoid.copy(alpha = 0.9f))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Terminal,
                        contentDescription = null,
                        tint = ElectricCyan,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = stringResource(R.string.terminal_title),
                        style = MaterialTheme.typography.labelMedium,
                        color = ElectricCyan
                    )
                }
                Text(
                    text = stringResource(R.string.terminal_clear),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary,
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .clickable { onClearLogs() }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                        .testTag("terminal_clear_button")
                )
            }

            LazyColumn(
                state = terminalListState,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(106.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CyberVoid)
                    .border(1.dp, CyberBorder, RoundedCornerShape(10.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .testTag("python_terminal_log"),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                items(uiState.terminalLogs, key = { it.id }) { line ->
                    val color = when (line.level) {
                        TerminalLogLevel.CMD -> ElectricCyan
                        TerminalLogLevel.INFO -> TextPrimary
                        TerminalLogLevel.HEX -> NeonAmber
                        TerminalLogLevel.WARN -> NeonCrimson
                        TerminalLogLevel.SUCCESS -> TerminalGreen
                    }
                    Text(
                        text = "${line.timestamp} ${line.text}",
                        style = MaterialTheme.typography.labelSmall,
                        color = color
                    )
                }
            }

            Button(
                onClick = onInjectBypass,
                enabled = uiState.bypassState != BypassState.INJECTING,
                colors = ButtonDefaults.buttonColors(
                    containerColor = when (uiState.bypassState) {
                        BypassState.ACTIVE -> TerminalGreen.copy(alpha = 0.22f)
                        else -> NeonCrimson
                    },
                    contentColor = when (uiState.bypassState) {
                        BypassState.ACTIVE -> TerminalGreen
                        else -> TextPrimary
                    }
                ),
                border = if (uiState.bypassState == BypassState.ACTIVE) {
                    androidx.compose.foundation.BorderStroke(1.dp, TerminalGreen)
                } else null,
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .minimumInteractiveComponentSize()
                    .testTag("inject_python_button")
            ) {
                if (uiState.bypassState == BypassState.INJECTING) {
                    CircularProgressIndicator(
                        color = TextPrimary,
                        strokeWidth = 2.dp,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(R.string.btn_injecting),
                        style = MaterialTheme.typography.titleMedium
                    )
                } else {
                    Icon(
                        imageVector = Icons.Filled.Bolt,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (uiState.bypassState == BypassState.ACTIVE) {
                            stringResource(R.string.btn_reinject)
                        } else {
                            stringResource(R.string.btn_inject_python)
                        },
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }

    if (uiState.showHtmlExportDialog) {
        val clipboardManager = LocalClipboardManager.current
        var copied by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = onDismissHtmlDialog,
            containerColor = CyberCard,
            titleContentColor = ElectricCyan,
            textContentColor = TextPrimary,
            title = {
                Text(
                    text = stringResource(R.string.export_dialog_title),
                    style = MaterialTheme.typography.headlineSmall
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = stringResource(R.string.export_dialog_desc),
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberVoid)
                            .border(1.dp, CyberBorder, RoundedCornerShape(8.dp))
                            .verticalScroll(rememberScrollState())
                            .padding(8.dp)
                    ) {
                        Text(
                            text = SingleFileHtmlTemplate.htmlSource,
                            style = MaterialTheme.typography.labelSmall,
                            color = TerminalGreen
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        clipboardManager.setText(AnnotatedString(SingleFileHtmlTemplate.htmlSource))
                        copied = true
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricCyan,
                        contentColor = CyberVoid
                    )
                ) {
                    Text(
                        text = if (copied) {
                            stringResource(R.string.export_copied)
                        } else {
                            stringResource(R.string.export_copy_btn)
                        },
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissHtmlDialog) {
                    Text(
                        text = stringResource(R.string.export_close_btn),
                        color = TextSecondary
                    )
                }
            }
        )
    }
}
