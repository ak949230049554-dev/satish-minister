package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val NexusDarkColorScheme = darkColorScheme(
    primary = ElectricCyan,
    onPrimary = CyberVoid,
    primaryContainer = ElectricCyanDim,
    onPrimaryContainer = TextPrimary,
    secondary = NeonCrimson,
    onSecondary = TextPrimary,
    secondaryContainer = NeonCrimsonDim,
    onSecondaryContainer = TextPrimary,
    tertiary = TerminalGreen,
    onTertiary = CyberVoid,
    background = CyberVoid,
    onBackground = TextPrimary,
    surface = CyberSurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberCard,
    onSurfaceVariant = TextSecondary,
    outline = CyberBorder,
    error = NeonCrimson,
    onError = TextPrimary
)

@Composable
fun NexusHudTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = NexusDarkColorScheme,
        typography = Typography,
        content = content
    )
}
