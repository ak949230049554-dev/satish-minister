package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.BypassState
import com.example.model.CrosshairStyle
import com.example.model.ModMenuUiState
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberGlass
import com.example.ui.theme.CyberVoid
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCrimson
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.hypot
import kotlin.math.roundToInt

@Composable
fun SimulationArenaOverlay(
    uiState: ModMenuUiState,
    onToggleMenu: () -> Unit,
    onCollapseMenu: () -> Unit,
    onLockSession: () -> Unit,
    onToggleEsp: (Boolean) -> Unit,
    onToggleEspSnaplines: (Boolean) -> Unit,
    onToggleAimbot: (Boolean) -> Unit,
    onFovChange: (Float) -> Unit,
    onSmoothnessChange: (Float) -> Unit,
    onToggleCrosshair: (Boolean) -> Unit,
    onSelectCrosshairStyle: (CrosshairStyle) -> Unit,
    onToggleFpsBoost: (Boolean) -> Unit,
    onClearLogs: () -> Unit,
    onInjectBypass: () -> Unit,
    onOpenHtmlDialog: () -> Unit,
    onDismissHtmlDialog: () -> Unit,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val textMeasurer = rememberTextMeasurer()
    val safeInsets = WindowInsets.safeDrawing.asPaddingValues()

    val infiniteTransition = rememberInfiniteTransition(label = "hud_pulse")
    val radarSweep by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_sweep"
    )
    val bubbleGlow by infiniteTransition.animateFloat(
        initialValue = 0.55f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bubble_glow"
    )

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(CyberVoid)
    ) {
        val totalWidthPx = with(density) { maxWidth.toPx() }
        val totalHeightPx = with(density) { maxHeight.toPx() }
        val topInsetPx = with(density) { safeInsets.calculateTopPadding().toPx() }
        val bottomInsetPx = with(density) { safeInsets.calculateBottomPadding().toPx() }
        val bubbleSizePx = with(density) { 56.dp.toPx() }
        val marginPx = with(density) { 12.dp.toPx() }

        var bubbleOffsetX by remember(totalWidthPx) {
            mutableFloatStateOf(marginPx)
        }
        var bubbleOffsetY by remember(topInsetPx) {
            mutableFloatStateOf(topInsetPx + with(density) { 64.dp.toPx() })
        }

        var panelOffsetX by remember { mutableFloatStateOf(0f) }
        var panelOffsetY by remember { mutableFloatStateOf(0f) }

        // 1. Live Tactical Game Arena + ESP + FOV Circle + Pro Crosshair Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val center = Offset(w / 2f, h / 2f)

            // Subtle cyber arena background radial gradient
            drawRect(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFF0E1424), CyberVoid),
                    center = center,
                    radius = maxOf(w, h) * 0.7f
                )
            )

            // Tactical grid lines
            val gridStep = 42.dp.toPx()
            var gx = 0f
            while (gx < w) {
                drawLine(
                    color = ElectricCyan.copy(alpha = 0.055f),
                    start = Offset(gx, 0f),
                    end = Offset(gx, h),
                    strokeWidth = 1f
                )
                gx += gridStep
            }
            var gy = 0f
            while (gy < h) {
                drawLine(
                    color = ElectricCyan.copy(alpha = 0.055f),
                    start = Offset(0f, gy),
                    end = Offset(w, gy),
                    strokeWidth = 1f
                )
                gy += gridStep
            }

            // Horizon & radar pulse ring
            drawLine(
                color = NeonCrimson.copy(alpha = 0.16f),
                start = Offset(0f, center.y),
                end = Offset(w, center.y),
                strokeWidth = 1.dp.toPx(),
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f), 0f)
            )
            val pulseRadius = (minOf(w, h) * 0.45f) * radarSweep
            drawCircle(
                color = ElectricCyan.copy(alpha = (1f - radarSweep) * 0.18f),
                radius = pulseRadius,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )

            val fovPx = uiState.aimbotFovRadius.dp.toPx()

            // Track closest enemy inside FOV for magnetic aimbot vector
            var lockedTargetPos: Offset? = null
            var closestDist = Float.MAX_VALUE

            // Simulated Enemies & ESP Hitboxes
            uiState.enemies.forEach { enemy ->
                val ex = enemy.normX * w
                val ey = enemy.normY * h
                val boxW = 40.dp.toPx()
                val boxH = 74.dp.toPx()
                val headOffset = Offset(ex, ey - boxH * 0.34f)

                val distToReticle = hypot(ex - center.x, ey - center.y)
                val inFov = uiState.aimbotEnabled && distToReticle <= fovPx

                if (inFov && distToReticle < closestDist) {
                    closestDist = distToReticle
                    lockedTargetPos = headOffset
                }

                // Base target silhouette (always visible in simulation arena)
                drawCircle(
                    color = Color(0xFF28334D),
                    radius = 7.dp.toPx(),
                    center = headOffset
                )
                drawRoundRect(
                    color = Color(0xFF1E273B),
                    topLeft = Offset(ex - 11.dp.toPx(), ey - boxH * 0.2f),
                    size = Size(22.dp.toPx(), boxH * 0.56f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx())
                )

                if (uiState.espEnabled) {
                    val espColor = if (inFov) ElectricCyan else NeonCrimson
                    val left = ex - boxW / 2f
                    val top = ey - boxH / 2f
                    val right = ex + boxW / 2f
                    val bottom = ey + boxH / 2f
                    val cornerLen = 11.dp.toPx()
                    val strokeW = 2.dp.toPx()

                    // Dim fill inside hitbox
                    drawRect(
                        color = espColor.copy(alpha = 0.08f),
                        topLeft = Offset(left, top),
                        size = Size(boxW, boxH)
                    )

                    // Tactical Corner Brackets
                    // Top-Left
                    drawLine(espColor, Offset(left, top), Offset(left + cornerLen, top), strokeW)
                    drawLine(espColor, Offset(left, top), Offset(left, top + cornerLen), strokeW)
                    // Top-Right
                    drawLine(espColor, Offset(right, top), Offset(right - cornerLen, top), strokeW)
                    drawLine(espColor, Offset(right, top), Offset(right, top + cornerLen), strokeW)
                    // Bottom-Left
                    drawLine(espColor, Offset(left, bottom), Offset(left + cornerLen, bottom), strokeW)
                    drawLine(espColor, Offset(left, bottom), Offset(left, bottom - cornerLen), strokeW)
                    // Bottom-Right
                    drawLine(espColor, Offset(right, bottom), Offset(right - cornerLen, bottom), strokeW)
                    drawLine(espColor, Offset(right, bottom), Offset(right, bottom - cornerLen), strokeW)

                    // Head hitbox ring
                    drawCircle(
                        color = espColor,
                        radius = 4.dp.toPx(),
                        center = headOffset,
                        style = Stroke(width = 1.5.dp.toPx())
                    )

                    // Snaplines from top center
                    if (uiState.espSnaplines) {
                        drawLine(
                            color = espColor.copy(alpha = 0.42f),
                            start = Offset(center.x, topInsetPx + 52.dp.toPx()),
                            end = Offset(ex, top),
                            strokeWidth = 1.dp.toPx()
                        )
                    }

                    // HP Bar
                    val hpBarTop = top - 8.dp.toPx()
                    val hpBarH = 4.dp.toPx()
                    drawRect(
                        color = Color(0xCC06070B),
                        topLeft = Offset(left, hpBarTop),
                        size = Size(boxW, hpBarH)
                    )
                    val hpColor = when {
                        enemy.hp > 0.6f -> TerminalGreen
                        enemy.hp > 0.32f -> NeonAmber
                        else -> NeonCrimson
                    }
                    drawRect(
                        color = hpColor,
                        topLeft = Offset(left, hpBarTop),
                        size = Size(boxW * enemy.hp, hpBarH)
                    )

                    // Player Info & Distance Label
                    val tagText = "${enemy.name} [${enemy.distanceM}m]"
                    val measured = textMeasurer.measure(
                        text = tagText,
                        style = TextStyle(
                            fontFamily = JetBrainsMonoFontFamily,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    val labelX = (ex - measured.size.width / 2f).coerceIn(4f, w - measured.size.width - 4f)
                    val labelY = (hpBarTop - measured.size.height - 3.dp.toPx()).coerceAtLeast(topInsetPx + 4f)
                    drawRect(
                        color = Color(0xB306070B),
                        topLeft = Offset(labelX - 3.dp.toPx(), labelY - 1.dp.toPx()),
                        size = Size(measured.size.width + 6.dp.toPx(), measured.size.height + 2.dp.toPx())
                    )
                    drawText(
                        textLayoutResult = measured,
                        topLeft = Offset(labelX, labelY)
                    )
                }
            }

            // Aimbot FOV Circle & Magnetic Target Lock Line
            if (uiState.aimbotEnabled) {
                drawCircle(
                    color = ElectricCyan.copy(alpha = 0.14f),
                    radius = fovPx,
                    center = center,
                    style = Stroke(width = 6.dp.toPx())
                )
                drawCircle(
                    color = ElectricCyan.copy(alpha = 0.85f),
                    radius = fovPx,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                lockedTargetPos?.let { target ->
                    // Smoothness modulates line dash/intensity visual
                    val lockAlpha = (1.1f - (uiState.aimbotSmoothness / 15f)).coerceIn(0.4f, 0.95f)
                    drawLine(
                        color = ElectricCyan.copy(alpha = lockAlpha),
                        start = center,
                        end = target,
                        strokeWidth = 1.8.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
                    )
                    drawCircle(
                        color = NeonCrimson,
                        radius = 6.dp.toPx(),
                        center = target,
                        style = Stroke(width = 2.dp.toPx())
                    )
                }
            }

            // Custom Pro Crosshair
            if (uiState.crosshairEnabled) {
                when (uiState.crosshairStyle) {
                    CrosshairStyle.TACTICAL_PLUS -> {
                        val arm = 12.dp.toPx()
                        val gap = 4.dp.toPx()
                        val sw = 2.2.dp.toPx()
                        drawLine(NeonCrimson, Offset(center.x - arm, center.y), Offset(center.x - gap, center.y), sw, StrokeCap.Round)
                        drawLine(NeonCrimson, Offset(center.x + gap, center.y), Offset(center.x + arm, center.y), sw, StrokeCap.Round)
                        drawLine(NeonCrimson, Offset(center.x, center.y - arm), Offset(center.x, center.y - gap), sw, StrokeCap.Round)
                        drawLine(NeonCrimson, Offset(center.x, center.y + gap), Offset(center.x, center.y + arm), sw, StrokeCap.Round)
                        drawCircle(ElectricCyan, radius = 1.8.dp.toPx(), center = center)
                    }
                    CrosshairStyle.CYBER_DOT -> {
                        drawCircle(
                            color = ElectricCyan,
                            radius = 7.dp.toPx(),
                            center = center,
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                        drawCircle(
                            color = NeonCrimson,
                            radius = 2.8.dp.toPx(),
                            center = center
                        )
                    }
                    CrosshairStyle.DYNAMIC_X -> {
                        val d = 9.dp.toPx()
                        val gap = 3.5.dp.toPx()
                        val sw = 2.dp.toPx()
                        drawLine(ElectricCyan, Offset(center.x - d, center.y - d), Offset(center.x - gap, center.y - gap), sw, StrokeCap.Round)
                        drawLine(ElectricCyan, Offset(center.x + gap, center.y + gap), Offset(center.x + d, center.y + d), sw, StrokeCap.Round)
                        drawLine(ElectricCyan, Offset(center.x + d, center.y - d), Offset(center.x + gap, center.y - gap), sw, StrokeCap.Round)
                        drawLine(ElectricCyan, Offset(center.x - gap, center.y + gap), Offset(center.x - d, center.y + d), sw, StrokeCap.Round)
                        drawCircle(NeonCrimson, radius = 2.dp.toPx(), center = center)
                    }
                }
            }
        }

        // 2. Top 120 FPS & Anti-Lag Telemetry HUD
        TopTelemetryHud(
            uiState = uiState,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = safeInsets.calculateTopPadding() + 8.dp, start = 12.dp, end = 12.dp)
        )

        // Bottom subtle hint when menu is collapsed
        AnimatedVisibility(
            visible = !uiState.isMenuExpanded,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = safeInsets.calculateBottomPadding() + 14.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .background(CyberGlass)
                    .border(1.dp, CyberBorder, RoundedCornerShape(999.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = stringResource(R.string.hud_sim_banner),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }
        }

        // 3. Expandable Cyberpunk Mod Menu Floating Window
        AnimatedVisibility(
            visible = uiState.isMenuExpanded,
            enter = fadeIn(tween(180)) + scaleIn(initialScale = 0.92f),
            exit = fadeOut(tween(150)) + scaleOut(targetScale = 0.92f),
            modifier = Modifier
                .align(Alignment.Center)
                .padding(
                    top = safeInsets.calculateTopPadding() + 56.dp,
                    bottom = safeInsets.calculateBottomPadding() + 16.dp,
                    start = 16.dp,
                    end = 16.dp
                )
                .offset { IntOffset(panelOffsetX.roundToInt(), panelOffsetY.roundToInt()) }
        ) {
            val maxMenuHeight = (maxHeight - safeInsets.calculateTopPadding() - safeInsets.calculateBottomPadding() - 78.dp)
                .coerceAtLeast(320.dp)
            ModMenuOverlayPanel(
                uiState = uiState,
                maxPanelHeight = maxMenuHeight,
                onDragPanel = { delta ->
                    val maxDx = (totalWidthPx * 0.25f)
                    val maxDy = (totalHeightPx * 0.20f)
                    panelOffsetX = (panelOffsetX + delta.x).coerceIn(-maxDx, maxDx)
                    panelOffsetY = (panelOffsetY + delta.y).coerceIn(-maxDy, maxDy)
                },
                onCollapse = onCollapseMenu,
                onLockSession = onLockSession,
                onToggleEsp = onToggleEsp,
                onToggleEspSnaplines = onToggleEspSnaplines,
                onToggleAimbot = onToggleAimbot,
                onFovChange = onFovChange,
                onSmoothnessChange = onSmoothnessChange,
                onToggleCrosshair = onToggleCrosshair,
                onSelectCrosshairStyle = onSelectCrosshairStyle,
                onToggleFpsBoost = onToggleFpsBoost,
                onClearLogs = onClearLogs,
                onInjectBypass = onInjectBypass,
                onOpenHtmlDialog = onOpenHtmlDialog,
                onDismissHtmlDialog = onDismissHtmlDialog
            )
        }

        // 4. Draggable Floating Bubble Icon (Always pinned above viewport)
        Box(
            modifier = Modifier
                .offset { IntOffset(bubbleOffsetX.roundToInt(), bubbleOffsetY.roundToInt()) }
                .size(56.dp)
                .minimumInteractiveComponentSize()
                .pointerInput(totalWidthPx, totalHeightPx, topInsetPx, bottomInsetPx) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val minX = marginPx
                        val maxX = (totalWidthPx - bubbleSizePx - marginPx).coerceAtLeast(minX)
                        val minY = topInsetPx + marginPx
                        val maxY = (totalHeightPx - bubbleSizePx - bottomInsetPx - marginPx).coerceAtLeast(minY)
                        bubbleOffsetX = (bubbleOffsetX + dragAmount.x).coerceIn(minX, maxX)
                        bubbleOffsetY = (bubbleOffsetY + dragAmount.y).coerceIn(minY, maxY)
                    }
                }
                .shadow(
                    elevation = 12.dp,
                    shape = CircleShape,
                    ambientColor = ElectricCyan,
                    spotColor = NeonCrimson
                )
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1F263B), CyberVoid)
                    )
                )
                .border(
                    width = 2.dp,
                    brush = Brush.sweepGradient(
                        listOf(
                            ElectricCyan.copy(alpha = bubbleGlow),
                            NeonCrimson.copy(alpha = bubbleGlow),
                            ElectricCyan.copy(alpha = bubbleGlow)
                        )
                    ),
                    shape = CircleShape
                )
                .clickable { onToggleMenu() }
                .testTag("floating_bubble_button"),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Filled.GpsFixed,
                contentDescription = stringResource(R.string.bubble_expand_desc),
                tint = if (uiState.isMenuExpanded) NeonCrimson else ElectricCyan,
                modifier = Modifier.size(26.dp)
            )
            // Bypass Active micro indicator dot
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(
                        when (uiState.bypassState) {
                            BypassState.ACTIVE -> TerminalGreen
                            BypassState.INJECTING -> NeonAmber
                            BypassState.IDLE -> NeonCrimson
                        }
                    )
                    .border(1.dp, CyberVoid, CircleShape)
            )
        }
    }
}

@Composable
private fun TopTelemetryHud(
    uiState: ModMenuUiState,
    modifier: Modifier = Modifier
) {
    val active = uiState.fpsBoostEnabled
    val borderColor = if (active) ElectricCyan.copy(alpha = 0.75f) else CyberBorder

    Row(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(CyberGlass)
            .border(1.dp, borderColor, RoundedCornerShape(999.dp))
            .padding(horizontal = 14.dp, vertical = 7.dp)
            .testTag("telemetry_hud"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        TelemetryMetric(
            label = "FPS",
            value = "${uiState.currentFps}",
            valueColor = if (active) ElectricCyan else TextSecondary
        )
        TelemetryDivider()
        TelemetryMetric(
            label = "PING",
            value = "${uiState.currentPingMs}ms",
            valueColor = if (active) TerminalGreen else NeonAmber
        )
        TelemetryDivider()
        TelemetryMetric(
            label = "FRAME",
            value = String.format("%.1fms", uiState.frameTimeMs),
            valueColor = TextPrimary
        )
        if (active) {
            TelemetryDivider()
            Text(
                text = "ANTI-LAG",
                style = MaterialTheme.typography.labelSmall,
                color = TerminalGreen,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun TelemetryMetric(
    label: String,
    value: String,
    valueColor: Color
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = "$label ",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelMedium,
            color = valueColor,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun TelemetryDivider() {
    Box(
        modifier = Modifier
            .width(1.dp)
            .size(width = 1.dp, height = 12.dp)
            .background(CyberBorder)
    )
}
