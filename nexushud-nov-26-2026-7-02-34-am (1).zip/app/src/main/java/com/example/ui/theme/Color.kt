package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberVoid = Color(0xFF06070B)
val CyberSurface = Color(0xFF0C0E15)
val CyberGlass = Color(0xE60E111A)
val CyberCard = Color(0xFF141824)
val CyberCardElevated = Color(0xFF1A1F2E)
val CyberBorder = Color(0xFF262D40)

val NeonCrimson = Color(0xFFFF1E42)
val NeonCrimsonDim = Color(0xFF991229)
val NeonCrimsonGlow = Color(0x55FF1E42)

val ElectricCyan = Color(0xFF00F0FF)
val ElectricCyanDim = Color(0xFF008B99)
val ElectricCyanGlow = Color(0x4400F0FF)

val TerminalGreen = Color(0xFF39FF88)
val NeonAmber = Color(0xFFFFB800)

val TextPrimary = Color(0xFFF2F5FA)
val TextSecondary = Color(0xFF8C96B0)
val TextMuted = Color(0xFF56607A)
